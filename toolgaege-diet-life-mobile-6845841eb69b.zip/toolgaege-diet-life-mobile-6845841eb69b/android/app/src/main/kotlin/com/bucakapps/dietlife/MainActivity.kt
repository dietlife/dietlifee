package com.bucakapps.dietlife

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
