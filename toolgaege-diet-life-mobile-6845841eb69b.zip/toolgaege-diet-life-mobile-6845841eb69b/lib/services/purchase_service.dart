



import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';

// This is just a development prototype for locally storing consumables. Do not
// use this.

// Original code link: https://github.com/flutter/plugins/blob/master/packages/in_app_purchase/example/lib/consumable_store.dart

class ConsumableStore {
  static const String _kPrefKey = 'consumables';
  static Future<void> _writes = Future.value();

  static Future<void> save(String id) {
    _writes = _writes.then((void _) => _doSave(id));
    return _writes;
  }

  static Future<void> consume(String id) {
    _writes = _writes.then((void _) => _doConsume(id));
    return _writes;
  }

  static Future<List<String>> load() async {
    return (await SharedPreferences.getInstance()).getStringList(_kPrefKey) ??
        [];
  }

  static Future<void> _doSave(String id) async {
    List<String> cached = await load();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    cached.add(id);
    await prefs.setStringList(_kPrefKey, cached);
    print('sadasdasdadasdasdasdasdasdasdsadasdsadasdasdasdsadsadasdasdasdasdasdasdas\nasdsadasdsadasdsadasdaasdsadsadsadasdasd' + _kPrefKey.toString() + 'asdasdasdsadsadasdasdsadasdasdasdsadsad' + cached.toString());
  }

  static Future<void> _doConsume(String id) async {
    List<String> cached = await load();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    cached.remove(id);
    await prefs.setStringList(_kPrefKey, cached);
  }
}







/*
import 'package:flutter/services.dart';
import 'base_model.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io' show Platform;



class PurchasesService extends BaseModel {
  PurchaserInfo _purchaserInfo;
  bool isPro;
  String satinAlmaIslem = '';


  Future<PurchaserInfo> initPlatformState() async {
    await Purchases.setDebugLogsEnabled(true);
    await Purchases.setup("zOlwlpTNvSlDbbvXCMzJHHznVjGnrEAW");
    PurchaserInfo purchaserInfo = await Purchases.getPurchaserInfo();

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    _purchaserInfo = purchaserInfo;
    notifyListeners();
    return purchaserInfo;
  }

  Future<Offerings> fetchData() async {
    Offerings offerings;
    try {
      offerings = await Purchases.getOfferings();
    } on PlatformException catch (e) {
      print(e);
    }
    notifyListeners();
    return offerings;
  }

  Future<PurchaserInfo> buyPackage(Package package) async {
    PurchaserInfo purchaserInfo = await Purchases.purchasePackage(package);
    var prefs = await SharedPreferences.getInstance();
    purchaserInfo.activeSubscriptions != null ||
            purchaserInfo.activeSubscriptions != []
        ? prefs.setBool("premiumState", true)
        : prefs.setBool("premiumState", false);
    notifyListeners();
    return purchaserInfo;
  }

  listenPurchaseUpdate() async {

    String os = Platform.operatingSystem;
    if(os == 'ios'){
      satinAlmaIslem = 'diyetlife';
    }else{
      satinAlmaIslem = 'diyetlife_';
    }


   await Purchases.addPurchaserInfoUpdateListener((purchaserInfo) => {
          if (purchaserInfo.entitlements.all[satinAlmaIslem].isActive)
            {isPro = true}
          else
            {isPro = false}
        });
    notifyListeners();
  }
}


 */