
class MyGlobals{
String userId = '';
}

