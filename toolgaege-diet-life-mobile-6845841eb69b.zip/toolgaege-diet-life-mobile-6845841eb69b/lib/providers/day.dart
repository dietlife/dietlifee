import 'package:flutter/cupertino.dart';


class Day with ChangeNotifier {

   String id;
   int dayNumber;
   int calori;
   String date;


  Day({
    @required this.id,
    @required this.dayNumber,
    @required this.calori,
    @required this.date
  });

}