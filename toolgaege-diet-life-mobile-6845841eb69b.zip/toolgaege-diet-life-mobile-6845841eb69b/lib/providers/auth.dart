import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'constants.dart';

class Auth with ChangeNotifier{
  String _token;
  String _userId;
  String _refreshToken;



  bool get isAuth{
    return token != null;
  }

  String get token{
    if(
        _token!=null
    ){
      return _token;
    }
    return null;
  }

  String get userId{
    return _userId;
  }

  Future<void> sendEmail(String email) async{
    final url = '${Constants.uri}/v1/accounts:sendOobCode?key=${Constants.api}';
    print('1');
    try{
      final response = await http.post(url,body: json.encode({
        'requestType':'PASSWORD_RESET',
        'email':email,
      }));
      print('1');
      final responseData = json.decode(response.body);
      print('1');
      if(responseData['error'] != null){
        print(responseData['error']);
        throw HttpException(responseData['error']['message']);
      }else{
        print(responseData['email']);
      }

    }catch(error){
      throw error;
    }


  }

  Future<void> _authenticate(String email, String password,String name,String surname,String urlSegment) async{
    final url = '${Constants.uri}/v1/accounts:$urlSegment?key=${Constants.api}';
    print('1');
    try{
      final response = await http.post(url,body: json.encode({
        'email':email,
        'password':password,
        'returnSecureToken':true
      }));
      print('1');
      final responseData = json.decode(response.body);
      print('1');
      if(responseData['error'] != null){
        print('2');
        throw HttpException(responseData['error']['message']);
      }
      print('3');
      _token = responseData['idToken'];
      _userId = responseData['localId'];
      _refreshToken = responseData['refreshToken'];
      print('1');
      notifyListeners();
      final prefs = await SharedPreferences.getInstance();
      final userData = json.encode({
        'token':_token,
        'userId':_userId,
        'refreshToken':_refreshToken,
      });
      await prefs.setString('userData', userData);
      notifyListeners();

      if(urlSegment=='signUp'){
        final urll = '${Constants.url}/users/$_userId.json?auth=$_token';
        try{
          final response = await http.put(urll,body:json.encode({
            'id':_userId,
            'name':name,
            'surname':surname,
            'email':email,
          }));
        }catch(error){
          print('afgsd $error');
          throw error;
        }
      }




    }catch(error){
      throw error;
    }


  }

  Future<void> signup(String email,String password,String name,String surname) async{
    return _authenticate(email, password,name,surname, 'signUp');
  }

  Future<void> login(String email, String password) async{
    return _authenticate(email, password,'','', 'signInWithPassword');
  }

  Future<bool> tryAutoLogin() async{
    print('debug start');
    final prefs = await SharedPreferences.getInstance();
    if(!prefs.containsKey('userData')){
      print('data bulunamadi');
      return false;
    }

    final extractedUserData = json.decode(prefs.getString('userData')) as Map<String,Object>;

    //final expiryDate = DateTime.parse(extractedUserData['expiryDate']);
//    if(expiryDate.isBefore(DateTime.now())){
//      return false;
//    }

    _token = extractedUserData['token'];
    _userId = extractedUserData['userId'];
    _refreshToken = extractedUserData['refreshToken'];
    notifyListeners();
    return true;
  }


  void logout() async{
    _userId = null;
    _token = null;
    final prefs = await SharedPreferences.getInstance();
    prefs.clear();
    notifyListeners();
  }


  Future<void> refreshSession() async {
    final url =
        'https://securetoken.googleapis.com/v1/token?key=${Constants.api}';
    //$WEB_API_KEY=> You should write your web api key on your firebase project.


    try {
      final response = await http.post(
        url,
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: {
          'grant_type': 'refresh_token',
          'refresh_token': _refreshToken, // Your refresh token.
        },
      );
      final responseData = json.decode(response.body);
      if (responseData['error'] != null) {
        throw HttpException(responseData['error']['message']);
      }
      _token = responseData['id_token'];
      _refreshToken = responseData['refresh_token']; // Also save your refresh token
      _userId = responseData['user_id'];
      notifyListeners();
      print('sdad');
      final prefs = await SharedPreferences.getInstance();
      final userData = json.encode({
        'token': _token,
        'userId': _userId,
        'refreshToken':_refreshToken
      });
      prefs.setString('userData', userData);
    } catch (error) {
      print('error: $error');
      throw error;
    }
  }



}