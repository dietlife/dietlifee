

import 'dart:convert';

import 'package:http/http.dart' as http;

import 'package:dietlife/providers/constants.dart';
import 'package:flutter/cupertino.dart';

class User with ChangeNotifier{

  final String userId;
  final String authToken;
  User(this.authToken,this.userId);



  String _id;
  String _name;
  String _surname;
  String _email;
  String _gender;
  int _boy;
  double _kilo;
  String _dogumGunu;
  int _aktivite;
  int _zorluk;
  int _istek;
  String _sonTarti;
  int _yas;
  bool _odemeDurumu;

  List<String> _tartiInfoList =[];

  Future<void> fetchAndSetUser() async{
    var url = '${Constants.url}/users/$userId.json?auth=$authToken';
    try{
      final response = await http.get(url);
      final extractedData = json.decode(response.body) as Map<String, dynamic>;
      if(extractedData == null){
        return;
      }


         _id= extractedData['id'];
         _name= extractedData['name'];
         _surname= extractedData['surname'];
         _email= extractedData['email'];
         _gender= extractedData['gender'];
         _boy= extractedData['boy'];
         _kilo= extractedData['kilo'];
         _dogumGunu= extractedData['yas'];
         _aktivite= extractedData['aktivite'];
         _zorluk= extractedData['zorluk'];
         _istek= extractedData['istek'];
         _sonTarti= extractedData['sonTarti'];
         _odemeDurumu= extractedData['odemeDurumu'] !=null ? extractedData['odemeDurumu'] : false;
        print("_odemeDurumu ${_odemeDurumu}");
         if(_dogumGunu!=null){
           _yas = DateTime.now().year-DateTime.parse(_dogumGunu).year;
         }


    }catch(error){
      throw (error);
    }

  }

  Future<void> fetchAndSetTarti() async{
    var url = '${Constants.url}/users/$userId/gecmisTartilar.json?auth=$authToken';
    try{
      final response = await http.get(url);
      final extractedData = json.decode(response.body) as Map<String, dynamic>;
      if(extractedData == null){
        return;
      }
      
      List<String> loadedInfo=[];
      extractedData.forEach((key, value) { 
        loadedInfo.add('${value['date']}&${value['kilo']}');
      });

      _tartiInfoList = loadedInfo;
      notifyListeners();


    }catch(error){
      throw (error);
    }

  }


  bool get getOdemeDurumu{
    return _odemeDurumu;
  }
  List get tartiInfiList{
    return _tartiInfoList;
  }

  String get id{
    return _id;
  }
  String get name{
    return _name;
  }
  String get surname{
    return _surname;
  }
  String get email{
    return _email;
  }
  String get gender{
    if(_gender == 'Male'){
      return 'Erkek';
    }
    return 'Kadın';
  }
  int get length{
    return _boy;
  }

  double get heavy{
    return _kilo;
  }


  int get age{
    return _yas;
  }

  String get aktivite{
    if(_aktivite ==1){
      return 'Hafif Düzey Aktivite';
    }else if(_aktivite == 2){
      return 'Orta Düzey Aktivite';
    }else if(_aktivite == 3){
      return 'Ağır Fiziksel Aktivite';
    }
  }

  String get zorluk{
    if(_zorluk ==1){
      return 'Kolay';
    }else if(_zorluk == 2){
      return 'Orta';
    }else if(_zorluk == 3){
      return 'Zor';
    }
  }

  String get istek{
    if(_istek ==1){
      return 'Kilo Vermek';
    }else if(_istek == 2){
      return 'Kilo Almak';
    }
  }

  String get sonTarti{
    return _sonTarti;
  }




  Future<void> setPersonelInfo(String gender, int boy,double kilo,String yas) async{


    final url = '${Constants.url}/users/$userId.json?auth=$authToken';
    await http.patch(url, body: json.encode({
      'gender':gender,
      'boy':boy,
      'kilo':kilo,
      'yas':yas,
      'sonTarti':DateTime.now().toIso8601String(),
      // 'odemeDurumu' : false
    }));

    await addGecmisTarti(kilo);


  }

  Future<void> addGecmisTarti(double kilo) async{


    final url = '${Constants.url}/users/$userId/gecmisTartilar.json?auth=$authToken';
    await http.post(url, body: json.encode({
      'kilo':kilo,
      'date':DateTime.now().toIso8601String()
    }));


  }
  Future<void> setOdemeDurumu(bool odeme) async{
    final url = '${Constants.url}/users/$userId.json?auth=$authToken';
    await http.patch(url, body: json.encode({
      'odemeDurumu':odeme,
    }));

  }
  Future<void> setKilo(double kilo) async{


    final url = '${Constants.url}/users/$userId.json?auth=$authToken';
    await http.patch(url, body: json.encode({
      'kilo':kilo,
    }));

    await addGecmisTarti(kilo);

  }

  Future<void> setAktiviteInfo(int aktivite) async{


    final url = '${Constants.url}/users/$userId.json?auth=$authToken';
    http.patch(url, body: json.encode({
      'aktivite':aktivite,
    }));

    _aktivite = aktivite;

  }

  Future<void> setIstekInfo(int istek) async{


    final url = '${Constants.url}/users/$userId.json?auth=$authToken';
    http.patch(url, body: json.encode({
      'istek':istek,
    }));


  }

  Future<void> setZorlukInfo(int zorluk) async{


    final url = '${Constants.url}/users/$userId.json?auth=$authToken';
    http.patch(url, body: json.encode({
      'zorluk':zorluk,
    }));

    _zorluk = zorluk;
  }

  Future<void> setYasInfo(String yas) async{


    final url = '${Constants.url}/users/$userId.json?auth=$authToken';
    http.patch(url, body: json.encode({
      'yas':yas,
    }));


  }

  int yuvarla(double kalori){
    var digit = kalori%100;
    print('digit:$digit');
    double c = kalori/100;
    int ca = c.toInt()*100;
    if(digit<=50){
      return ca;
    }else{
      return ca+100;
    }
  }

  
  int kaloriHesapla(){
    var kalori = yuvarla(getIhtiyac()+getKaloriAcigi());
    print(getIhtiyac()+getKaloriAcigi());
    print(kalori);
    return kalori;


  }

  double getIhtiyac(){
    return getBhm()*getAktivite()+(getBhm()/10);
  }


  int getKaloriAcigi(){
    if(_istek==1){
      if(_zorluk==1){
        return -700;
      }else if(_zorluk == 2){
        return -1000;
      }else if(_zorluk == 3){
        return -1200;
      }
    }else{
      if(_zorluk==1){
        return 700;
      }else if(_zorluk == 2){
        return 1000;
      }else if(_zorluk == 3){
        return 1200;
      }
    }
  }



  double getBki(){
    return _kilo/((_boy/100)*(_boy/100));
  }
  
  
  double getBhm(){
    print('yas: $_yas');
    if(_gender=='Male'){
      if(_yas>=18 && _yas<=30){
        return (15.3)*_kilo+679;
      }else if(_yas>=31 && _yas<=60){
        return (11.6)*_kilo+879;
      }else if(_yas>=61){
        return (13.5)*_kilo+487;
      }
    }else{
      if(_yas>=18 && _yas<=30){
        return (14.7)*_kilo+487;
      }else if(_yas>=31 && _yas<=60){
        return (8.7)*_kilo+829;
      }else if(_yas>=61){
        return (10.5)*_kilo+586;
      }
    }
  }

  double getAktivite(){
    if(_aktivite == 1){
      return 1.35;
    }else if(_aktivite == 2){
      return 1.55;
    }else if(_aktivite == 3){
      return 2.0;
    }
  }




//  User(
//      this.id,
//      this.name,
//      this.surname,
//      this.email,
//      this.gender,
//      this.length,
//      this.heavy,
//      this.age,
//      this.aktivite,
//      this.zorluk,
//      this.istek
//      );










}