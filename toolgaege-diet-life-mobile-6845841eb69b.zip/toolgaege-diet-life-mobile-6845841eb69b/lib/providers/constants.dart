
class Constants{

  static const url='https://dietlife-d97e5.firebaseio.com';
  static const api='AIzaSyApaBrRBfPoacQpceOFHoaGTMN1bxR00DI';
  static const uri='https://identitytoolkit.googleapis.com';

  static const pravicyPolicy = "<!DOCTYPE html>"+
"\n      <html>"+
"\n  <head>"+
"\n  <meta charset='utf-8'>"+
"\n  <meta name='viewport' content='width=device-width'>"+
"\n  <title>Privacy Policy</title>"+
"\n  <style> body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding:1em; } </style>"+
"\n</head>"+
"\n<body>"+
"\n<strong>Privacy Policy</strong> <p>"+
"\n AHMET KAPLAN built the DIETLIFE app as"+
"\n an Ad Supported app. This SERVICE is provided by"+
"\n AHMET KAPLAN at no cost and is intended for use as"+
"\n is."+
"\n</p> <p>"+
"\n This page is used to inform visitors regarding my"+
"\n policies with the collection, use, and disclosure of Personal"+
"\n Information if anyone decided to use my Service."+
"\n '</p> <p>"+
"\n If you choose to use my Service, then you agree to"+
"\n the collection and use of information in relation to this"+
"\n policy. The Personal Information that I collect is"+
"\n used for providing and improving the Service. I will not use or share your information with"+
"\n anyone except as described in this Privacy Policy."+
"\n '</p> <p>"+
"\n The terms used in this Privacy Policy have the same meanings"+
"\n as in our Terms and Conditions, which is accessible at"+
"\n DIETLIFE unless otherwise defined in this Privacy Policy."+
"\n '</p> <p><strong>Information Collection and Use</strong></p> <p>"+
"\n For a better experience, while using our Service, I"+
"\n may require you to provide us with certain personally"+
"\n identifiable information, including but not limited to AHMET KAPLAN. The information that"+
"\n I request will be retained on your device and is not collected by me in any way."+
"\n '</p> <div><p>"+
"\n The app does use third party services that may collect"+
"\n information used to identify you."+
"\n '</p> <p>"+
"\n Link to privacy policy of third party service providers used"+
"\n by the app"+
"\n </p> <ul><li><a href=\"https://www.google.com/policies/privacy/\" target=\"_blank\" rel=\"noopener noreferrer\">Google Play Services</a></li><!----><li><a href=\"https://firebase.google.com/policies/analytics\" target=\"_blank\" rel=\"noopener noreferrer\">Google Analytics for Firebase</a></li><li><a href=\"https://firebase.google.com/support/privacy/\" target=\"_blank\" rel=\"noopener noreferrer\">Firebase Crashlytics</a></li><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----></ul></div> <p><strong>Log Data</strong></p> <p>"+
"\n I want to inform you that whenever you"+
"\n use my Service, in a case of an error in the app"+
"\n I collect data and information (through third party"+
"\n products) on your phone called Log Data. This Log Data may"+
"\n include information such as your device Internet Protocol"+
"\n '(“IP”) address, device name, operating system version, the"+
"\n configuration of the app when utilizing my Service,"+
"\n '    the time and date of your use of the Service, and other"+
"\n statistics."+
"\n '</p> <p><strong>Cookies</strong></p> <p>"+
"\n Cookies are files with a small amount of data that are"+
"\n commonly used as anonymous unique identifiers. These are sent"+
"\n to your browser from the websites that you visit and are"+
"\n stored on your device's internal memory."+
"\n '</p> <p>"+
"\n This Service does not use these “cookies” explicitly. However,"+
"\n the app may use third party code and libraries that use"+
"\n '“cookies” to collect information and improve their services."+
"\n You have the option to either accept or refuse these cookies"+
"\n and know when a cookie is being sent to your device. If you"+
"\n choose to refuse our cookies, you may not be able to use some"+
"\n portions of this Service."+
"\n '</p> <p><strong>Service Providers</strong></p> <p>"+
"\n I may employ third-party companies and"+
"\n individuals due to the following reasons:"+
"\n '</p> <ul><li>To facilitate our Service;</li> <li>To provide the Service on our behalf;</li> <li>To perform Service-related services; or</li> <li>To assist us in analyzing how our Service is used.</li></ul> <p>"+
"\n I want to inform users of this Service"+
"\n that these third parties have access to your Personal"+
"\n Information. The reason is to perform the tasks assigned to"+
"\n them on our behalf. However, they are obligated not to"+
"\n disclose or use the information for any other purpose."+
"\n '</p> <p><strong>Security</strong></p> <p>"+
"\n I value your trust in providing us your"+
"\n Personal Information, thus we are striving to use commercially"+
"\n acceptable means of protecting it. But remember that no method"+
"\n of transmission over the internet, or method of electronic"+
"\n storage is 100% secure and reliable, and I cannot"+
"\n guarantee its absolute security."+
"\n '</p> <p><strong>Links to Other Sites</strong></p> <p>"+
"\n This Service may contain links to other sites. If you click on"+
"\n a third-party link, you will be directed to that site. Note"+
"\n that these external sites are not operated by me."+
"\n Therefore, I strongly advise you to review the"+
"\n Privacy Policy of these websites. I have"+
"\n no control over and assume no responsibility for the content,"+
"\n '    privacy policies, or practices of any third-party sites or"+
"\n services."+
"\n '</p> <p><strong>Children’s Privacy</strong></p> <p>"+
"\n These Services do not address anyone under the age of 18."+
"\n I do not knowingly collect personally"+
"\n identifiable information from children under 18. In the case"+
"\n I discover that a child under 18 has provided"+
"\n me with personal information, I immediately"+
"\n delete this from our servers. If you are a parent or guardian"+
"\n and you are aware that your child has provided us with"+
"\n personal information, please contact me so that"+
"\n I will be able to do necessary actions."+
"\n '</p> <p><strong>Changes to This Privacy Policy</strong></p> <p>"+
"\n I may update our Privacy Policy from"+
"\n time to time. Thus, you are advised to review this page"+
"\n periodically for any changes. I will"+
"\n notify you of any changes by posting the new Privacy Policy on"+
"\n this page."+
"\n '</p> <p>This policy is effective as of 2021-01-28</p> <p><strong>Contact Us</strong></p> <p>"+
"\n If you have any questions or suggestions about my"+
"\n Privacy Policy, do not hesitate to contact me at dietlifee@gmail.com."+
"\n '</p> <p>This privacy policy page was created at <a href=\"https://privacypolicytemplate.net\" target=\"_blank\" rel=\"noopener noreferrer\">privacypolicytemplate.net </a>and modified/generated by <a href=\"https://app-privacy-policy-generator.nisrulz.com/\" target=\"_blank\" rel=\"noopener noreferrer\">App Privacy Policy Generator</a></p>"+
"\n '</body>"+
"\n '</html>";





  static const pravicyPolicyTr = "<p style='margin: 5px 0px; text-align: "
      "justify; font-stretch: normal; font-size: 24px; line-height: normal; font-family: \"Times New Roman\" ; color: rgb(51, 51, 51);'><strong>DİETLİFE- GİZLİLİK POLİTİKASI</strong></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Son g&uuml;ncellenme: 30Ocak 2021</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bu gizlilik politikası &lsquo;&rsquo; Diet &nbsp;Life &nbsp;&lsquo;&rsquo; mobil uygulamasının kullanım ve veri işleme talimatlarıyla alakalıdır.&nbsp;</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><strong>1. Giriş</strong></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bu Politika yukarıda tanımlanan tarafımıza ait &Uuml;r&uuml;nlerden herhangi birini kullandığınızda edindiğimiz kişisel bilgilerin nasıl toplandığı, işlendiği ve kullanıldığını a&ccedil;ıklamaktadır.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Tarafımıza herhangi bir kişisel veri sağladığınızda bu veriyi kullanma şeklimiz a&ccedil;ısında size karşı yasal sorumluluklarımız bulunmaktadır. Okuma kolaylığı sağlaması a&ccedil;ısından bu Politikayı muhtelif b&ouml;l&uuml;mlere ayırmış bulunmaktayız:</p>"
  "<p style='margin: 0px 0px 0px 36px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<ul>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(0, 0, 255);'><span style=\"text-decoration: underline;\">Giriş</span></li>"
  "</ul>"
  "<p style='margin: 0px 0px 0px 36px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<ul>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(0, 0, 255);'><span style=\"text-decoration: underline;\">Kişisel veri nedir ve biz hangi kişisel verileri topluyoruz</span></li>"
  "</ul>"
  "<p style='margin: 0px 0px 0px 36px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<ul>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(0, 0, 255);'><span style=\"text-decoration: underline;\">Kişisel verilerinizi nasıl ve neden kullanıyoruz/paylaşıyoruz</span></li>"
  "</ul>"
  "<p style='margin: 0px 0px 0px 36px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<ul>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(0, 0, 255);'><span style=\"text-decoration: underline;\">Kişisel verilerinizi ne kadar s&uuml;re tutuyoruz</span></li>"
  "</ul>"
  "<p style='margin: 0px 0px 0px 36px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<ul>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(0, 0, 255);'><span style=\"text-decoration: underline;\">G&uuml;venlik</span></li>"
  "</ul>"
  "<p style='margin: 0px 0px 0px 36px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<ul>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(0, 0, 255);'><span style=\"text-decoration: underline;\">Haklarınız</span></li>"
  "</ul>"
  "<p style='margin: 0px 0px 0px 36px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<ul>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(0, 0, 255);'><span style=\"text-decoration: underline;\">İletişim Detayları</span></li>"
  "</ul>"
  "<p style='margin: 0px 0px 0px 36px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bu Gizlilik Politikasını, kişisel bilgilerinizi topladığımız ya da işlediğimiz zamanlarda &Uuml;r&uuml;nlerimiz hakkında sağlayabileceğimiz diğer gizlilik bildirimleri ve aydınlatma metinleri ile birlikte (&ouml;rneğin tarafımıza ait bulunan &Uuml;r&uuml;nlerden birini ilk kez indirdiğiniz ya da kullanmaya başladığınızda size sunabileceğimiz ya da tarafımızdan e-posta g&uuml;ncellemeleri almak i&ccedil;in kayıt olma imkanı verildiğinde size g&ouml;sterilebilecek olan) bu verileri nasıl ve neden kullandığımızı tam olarak anlamanız i&ccedil;in okumanız &ouml;nemlidir.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bu Politika, <span style=\"text-decoration: underline ; color: #0000ff;\">Hizmet Şartlarımızı</span>, <span style=\"text-decoration: underline ; color: #0000ff;\">&Ccedil;erez Politikamızı</span> ve tarafımıza ait olan (&Uuml;r&uuml;nden &Uuml;r&uuml;ne değişebilen) &Uuml;r&uuml;nler hakkındaki diğer bildirimlerin ve koşulların tamamlayıcısı niteliğinde olup bunları ge&ccedil;ersiz kılmaz ya da bunların yerine ge&ccedil;mez. &Uuml;r&uuml;nlerimizi ziyaret ederek ya da kullanarak bu Politikada ortaya konulmuş ve bu Politikadaki sınırlar dahilinde ger&ccedil;ekleştirilecek olan uygulamaları kişisel verilerin korunmasına ilişkin mevzuatın izin verdiği &ouml;l&ccedil;&uuml;de kabul etmiş sayılırsınız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Herhangi bir nedenden &ouml;t&uuml;r&uuml; bu Politikanın şartlarını kabul etmemeniz durumunda l&uuml;tfen bu &Uuml;r&uuml;nleri kullanmayı bırakınız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Faaliyetlerimizdeki ya da yasalardaki değişiklikleri yansıtması a&ccedil;ısından bu Politikayı tadil etme ya da değiştirme hakkını saklı tutarız. Diet Life, bu değişikliklerin &ouml;nemli olduğu durumlarda ilgili &Uuml;r&uuml;nlerin kullanıcılarını durumdan haberdar etmek ve bilgilendirmek i&ccedil;in gerekli &ccedil;abayı g&ouml;sterir. Ancak, &Uuml;r&uuml;nlerin kullanımından &ouml;nce her defa bu Politikayı kontrol etmek sizin sorumluluğunuzdadır. Referans kolaylığı sağlaması a&ccedil;ısından Politika&rsquo;nın son g&uuml;ncelleme tarihi Politikanın &uuml;st kısmında belirtilmiştir.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>L&uuml;tfen tarafımıza ait olan &Uuml;r&uuml;nlerin 13 yaş altındaki &ccedil;ocukların (her biri <strong>&quot;&Ccedil;ocuk&quot;</strong>, birlikte <strong>&quot;&Ccedil;ocuklar&quot;</strong>) kullanıma y&ouml;nelik olmadığını ve &ccedil;ocuklar hakkında kasten bilgi toplamadığımızı unutmayınız. &Ccedil;ocuğunuz hakkında kişisel veriler topladığımızı d&uuml;ş&uuml;n&uuml;yorsanız, <span style=\"color: #000000;\">dietlifee@gmail.com</span> adresi yoluyla bize ulaşabilir ve &Ccedil;ocuğunuz hakkındaki veri işleme faaliyetlerinin durdurulmasını talep edebilirsiniz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><strong>2. Kişisel Veri nedir ve biz neyi topluyoruz?</strong></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">Kişisel veri nedir?</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bu Politikada &quot;kişisel veri&quot; ifadesi ge&ccedil;tiğinde bu adınız, doğum tarihiniz, irtibat bilgileriniz ve hatta IP adresinizi gibi size tanımlamaya yardımcı olan hakkınızdaki bilgileri işaret etmektedir.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>T&uuml;rkiye&rsquo;deki t&uuml;m kuruluşların kişisel bilgilerinizi belirli şekillerde işleme ve size bu verileri nasıl kullandıklarına dair yeterli bilgi verme konusunda gibi yasal zorunlulukları bulunmaktadır. Ayrıca bu kuruluşlardan verilerinizi nasıl kullandıkları hakkında bilgi talep etme ve bu verileri yasadışı şekillerden kullanmalarını &ouml;nleme hakkına sahip bulunmaktasınız. Bu haklar hakkında daha fazla bilgi edinmek i&ccedil;in l&uuml;tfen bu Politikanın <span style=\"text-decoration: underline ; color: #0000ff;\">Haklarınız</span> b&ouml;l&uuml;m&uuml;ne bakınız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">&Uuml;r&uuml;nlerimizi kullanırken tarafınızdan topladığımız bilgiler</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">İsteğe Bağlı Veri Temini</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Tarafımıza isteğinize bağlı olarak; &ouml;rneğin kişisel verilerinizi y&uuml;klemek ya da yollamak i&ccedil;in &Uuml;r&uuml;nleri kullanarak (internet sitemizde bir form doldurarak, oyunlarımızın herhangi birinin profil sayfasında kişisel detaylarınızı vererek, m&uuml;şteri destek ekibimizle iletişime ge&ccedil;erek, yayınlarımızdan ya da b&uuml;ltenlerimizden birine abone olarak ya da hakkınızda g&ouml;n&uuml;ll&uuml; olarak bilgi verdiğiniz herhangi bir eylem yoluyla), posta, telefon, e-posta ya da SMS yoluyla tarafımızla iletişime ge&ccedil;erek, bir &Uuml;r&uuml;n hakkında sorun bildiriminde bulunarak kişisel verilerinizi sunduğunuzda; bize sunmuş olduğunuz kişisel verileri toplayabilir, saklayabilir ve kullanabiliriz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Sizden topladığımız bu kişisel veriler unvan, isim, adres, e-posta adresi, telefon numarası, işlem ve/veya kredi kartı bilgilerini i&ccedil;erebilir ancak kesinlikle &Uuml;r&uuml;nlerimiz yoluyla bizimle iletişime ge&ccedil;tiğinizde isteğinize bağlı olarak verdiğiniz detaylara dayanacaktır.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">Otomatik Veri Toplama</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Buna ek olarak bir tarafımıza ait &Uuml;r&uuml;nlerden birini ziyaret ettiğinizde &ccedil;erez gibi teknolojilerin kullanımı yoluyla hakkınızdaki kişisel verileri toplayabiliriz. Aşağıdakiler toplayabileceğimiz veri &ouml;rneklerini g&ouml;stermektedir:</p>"
  "<ul>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>(&quot;Reklam Verenler i&ccedil;in Tanımlayıcı&quot; ya da &quot;IDFA&quot; gibi cihazınızı tanımlayan eşsiz tanımlayıcılar da dahil olmak &uuml;zere) Cihazınız, tarayıcınız ya da işletim sisteminiz hakkındaki bilgiler;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>IP adresiniz ve &Uuml;r&uuml;nlerimize erişim sağlamak i&ccedil;in kullandığınız ağ hakkındaki bilgiler;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>&Uuml;r&uuml;nlerde tıkladığınız bağlantılar ve &Uuml;r&uuml;n&uuml;m&uuml;zde g&ouml;r&uuml;nt&uuml;lediğiniz sayfalar hakkında bilgiler;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>&Uuml;r&uuml;nlerimizde bulunan belirli sayfaları ziyaret s&uuml;reniz;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>G&ouml;r&uuml;nt&uuml;lediğiniz ya da araştırdığınız konu;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Sayfa yanıt s&uuml;releri;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>İndirme hataları ve/veya hatalı bağlantıların kayıtları;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Sayfa etkileşim bilgileri (kaydırma, tıklama ve fare &uuml;zeri hareketlerinizin detayları gibi) sayfa etkileşim bilgileri;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Sayfadan &ccedil;ıkmak i&ccedil;in kullanılan y&ouml;ntemler; ve</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>&Uuml;r&uuml;ne y&ouml;nelik, &Uuml;r&uuml;n yoluyla ya da &Uuml;r&uuml;nden Bir&ouml;rnek Kaynak Konumlandırıcıları (URL) tıklama davranışları (zaman ve tarih de dahil olmak &uuml;zere).</li>"
  "</ul>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Yukarıda ifade edilen bilgileri muhtelif sebeplerden &ouml;t&uuml;r&uuml; kullanmaktayız. Bu verileri &ouml;ncelikle &Uuml;r&uuml;nlerimizin d&uuml;zg&uuml;n bir şekilde &ccedil;alıştığından emin olmak ve bu &Uuml;r&uuml;nlerden eksiksiz bir şekilde faydalanmanızı sağlamak i&ccedil;in kullanmaktayız. Buna ek olarak, bu verileri &Uuml;r&uuml;nlerimiz arasındaki &ccedil;evrimi&ccedil;i trafiği ve kullanıcı katılımını g&ouml;r&uuml;nt&uuml;lemek i&ccedil;in kullanmaktayız. Bahsi ge&ccedil;en işleme ama&ccedil;larına ilişkin veri işleme faaliyetleri, kullanıcıların temel hak ve &ouml;zg&uuml;rl&uuml;klerine zarar vermemek kaydıyla, Diet Life&rsquo; ın meşru menfaatleri i&ccedil;in veri işlemenin zorunlu olmasına dayanmaktadır.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Ayrıca yukarıda ifade edilen verileri size &ccedil;eşitli hizmetleri sunabilmek i&ccedil;in kullanmaktayız. Bu hizmetlerin arasında destek taleplerinize yanıt verebilmek, y&uuml;ksek skorların kayıtlarının tutulması gibi oyun i&ccedil;i işlevlere erişim sağlamak, oyun i&ccedil;i satın alım yapabilmenizi sağlamak ve &Uuml;r&uuml;nlerimiz arasında arkadaşlarınızla iletişim ve bağlantı kurmanızı sağlamak da bulunmaktadır.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>&Uuml;r&uuml;nlerimiz, (Facebook gibi) sosyal medya platformlarına bağlanmanızı sağlayan &ccedil;eşitli işlevsellikler i&ccedil;ermektedir. Bu işlevi kullanmayı se&ccedil;meniz durumunda bu bağlantıların ger&ccedil;ekleşmesini sağlamak ve ger&ccedil;ekleştirdiğiniz bağlantıların kayıtlarını d&uuml;zg&uuml;n bir bi&ccedil;imde tutabilmek i&ccedil;in tarafınızdan &ccedil;eşitli verileri topluyor olacağız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">&Uuml;&ccedil;&uuml;nc&uuml; Taraf Kaynakları</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>&Uuml;r&uuml;nlerimiz sizlere reklamlar sunan &ccedil;eşitli &ouml;zellikler barındırmaktadır. Bu reklamların m&uuml;mk&uuml;n olduğunca ilgili olmalarını sağlamak i&ccedil;in (t&uuml;m &Uuml;r&uuml;n kullanıcılarına aynı materyali g&ouml;stermekten ziyade) hedef reklamları size y&ouml;nlendirebilmek adına siz ve ilgi alanlarınız hakkında detaylar toplayan ve kullanan &uuml;&ccedil;&uuml;nc&uuml; taraf reklam ağları kullanmaktayız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bu hizmetleri kullandığımız durumlarda sizlere hakkınızdaki verilerin bu ağlara sunulmak amacıyla iletilmesini ve toplanmasını engelleme imkanı sunacağız. Bu t&uuml;r bir ret reklamları g&ouml;rmenizi engellemez ancak size g&ouml;sterilen reklamların ilgililik d&uuml;zeyini azaltabilir.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Kullandığımız reklam ortakları hakkındaki detaylara ulaşmak i&ccedil;in l&uuml;tfen <span style=\"text-decoration: underline ; color: #0000ff;\">hizmet sağlayıcılarımızın</span> isimlerinin ve detaylarının mevcut olduğu aşağıdaki b&ouml;l&uuml;me bakınız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><strong>3. Kişisel verilerinizi nasıl ve neden kullanıyoruz/paylaşıyoruz</strong></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">Kişisel verilerinizin paylaşılması</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Kişisel verileriniz hi&ccedil;bir şekilde herhangi bir 3 taraf yazılım vb. paylaşılmamaktadır.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><strong>4. Kişisel verilerinizi ne kadar s&uuml;re tutuyoruz?</strong></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Kişisel verilerinizi sadece talep etmiş olduğunuz hizmetlerin tarafınıza sunulması ya da verinin toplanma amacının ger&ccedil;ekleştirilmesi i&ccedil;in gerekli olan s&uuml;reler boyunca sistemlerimizde tutmaktayız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Tarafımızdan elektronik posta bilgilendirmesi almayı se&ccedil;meniz ve sonrasında bu iletilerialmaktan vazge&ccedil;meniz halinde sizi listemizden &ccedil;ıkarabilmek adına e-posta adresinizi tutmaktayız. E-posta adresinizi bu t&uuml;r bir abonelikten &ccedil;ıkma isteği durumunda talebinizi yerine getirebilmek adına sistemimizde tutmaktayız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bazı durumlarda verilerinizi silmemizi talep edebilirsiniz. Daha fazla bilgi i&ccedil;in bkz: &quot;Haklarınız&quot;.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bazı durumlarda bilgilerinizi araştırma ya da istatistiksel ama&ccedil;larla (sizinle ilişkilendirilmemesi i&ccedil;in) anonim hale getirerek başkacabildirime gerek olmaksızın s&uuml;resiz olarak kullanabiliriz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><strong>5. G&uuml;venlik</strong></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Diet Life verilerinizin korunmasını hususunu olduk&ccedil;a ciddiye almaktadır. Uygulanabilir olduğu durumlarda kişisel verilerinizin korunması i&ccedil;in şifreleme (SSL) kullanır ve bize sağlanan t&uuml;m verilerin g&uuml;venli sunucularda saklanmasını sağlarız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Diet Life, kişisel verilerinizi ya kendi tesislerinde ya da &uuml;&ccedil;&uuml;nc&uuml; tarafların veri merkezlerinde saklayabilir.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Hizmet sağlayıcılarımızın bazıları Avrupa Ekonomik B&ouml;lgesi (&quot;AEB&quot;) dışındaki &uuml;lkelerde de bulunabilir. Bu hizmet sağlayıcıları bizim ya da tedarik&ccedil;ilerimizin biri i&ccedil;in &ccedil;alışıyor olabilir ve buna ek olarak, siparişinizin ger&ccedil;ekleştirilmesi, &ouml;deme detaylarının işlenmesi ve destek hizmetlerinin sunulması gibi faaliyetlerde bulunuyor olabilirler.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>&Ouml;zellikle bizimle destek hizmetleri i&ccedil;in muhatap olmanız durumunda (&ouml;rn., &Uuml;r&uuml;nlerimizden biri hakkında bir sorun bildirmek gibi) şikayetiniz b&uuml;y&uuml;k ihtimalle T&uuml;rkiye&rsquo;de bulunan destek ekibimiz tarafından ele alınacaktır.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Diet Life, Politika&rsquo;da belirtilen sınırlar &ccedil;er&ccedil;evesinde 6698 sayılı Kişisel Verilerin Korunması Kanunu ve ilgili mevzuat uyarınca kişisel verilerinizin işleyebilir, saklayabilir veya yurti&ccedil;inde veya yurtdışında aktarabilir. Verilerinizi T&uuml;rkiye dışında bulunan bir hizmet sağlayıcısına ilettiğimiz durumlarda kişisel verilerinizin g&uuml;venli bir şekilde tutulduğundan ve veri sahibi olarak haklarınızın korunduğundan emin olmak i&ccedil;in gerekli &ouml;nlemlerin alınmış olmasını sağlarız. Kişisel verilerin iletilmesi mekanizması hakkında daha fazla bilgi edinmek i&ccedil;in l&uuml;tfen <span style=\"color: #000000;\">dietlifee@gmail.com</span> yoluyla iletişime ge&ccedil;iniz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Tarafınıza (ya da se&ccedil;miş olduğunuz bir yere) bu &Uuml;r&uuml;n&uuml;n belirli kısımlarına erişim sağlayan bir şifre g&ouml;ndermemiz durumunda bu şifrenin gizli tutulması sizin sorumluluğunuzdadır. Bu şifreyi herhangi bir kişi ile paylaşmamızı talep ederiz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51); min-height: 16px;'><br></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><strong>6. Haklarınız</strong></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bir veri sahibi olarak başta 6698 sayılı Kişisel Verilerin Korunması Kanunu&rsquo;nun ilgili kişinin haklarını d&uuml;zenleyen 11. Maddesi kapsamındaki talepleriniz olmak &uuml;zere, kişisel verileriniz ile ilgili olarak &ccedil;eşitli haklara sahipsiniz. Aşağıda nasıl kullanacağınıza ek olarak sahip olduğunuz &ccedil;eşitli hakları tarif etmekteyiz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">Erişim Hakkı</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Herhangi bir zamanda olmak &uuml;zere tarafınızla ilgili olarak tuttuğumuz kişisel verilere erişim talep etme hakkına sahipsiniz (bu hakkı <strong>&quot;veri sahibinin erişim talebi&quot;</strong> olarak da duymuş olabilirsiniz).</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>L&uuml;tfen bu hakkın tarafınıza verilerinizin doğruluğunu kontrol edebilmenizi ve bu kişisel verileri yasalara uygun olarak işleme aldığımızdan emin olmanızı sağlamak adına kişisel verilerinizin bir kopyasını almak i&ccedil;in tanındığını unutmayınız. Bu, diğer kişilerin kişisel verilerini ya da kişisel verileriniz ile ilgili olmayan belgelerin talep etmeniz i&ccedil;in tarafınıza tanınmış bir hak değildir.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bu hakkı <span style=\"text-decoration: underline ; color: #0000ff;\">burada</span> belirtilmiş irtibat bilgilerini kullanıp bizimle iletişime ge&ccedil;erek ve bize bir veri sahibi erişim talebinde bulunduğunuzu belirterek kullanabilirsiniz. Bu t&uuml;r bir talepte bulunmak i&ccedil;in &ouml;zel bir form doldurmanıza gerek yoktur.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">D&uuml;zeltme ve Silme Hakkı</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Herhangi bir zamanda olmak &uuml;zere hatalı veya yanlış olduğunuzu d&uuml;ş&uuml;nd&uuml;ğ&uuml;n&uuml;z kişisel verilerin d&uuml;zeltilmesini talep etme hakkına sahipsiniz. Ayrıca saklamamızın gerekli olmadığını d&uuml;ş&uuml;nmeniz durumunda kişisel verileri silmemizi talep edebilirsiniz (bu hakkı &quot;unutma hakkı&quot; olarak da duymuş olabilirsiniz).</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>L&uuml;tfen bize sunmuş olduğunuz yeni verileri doğrulamanızı rica edebileceğimizi ve tarafımıza sağladığınız yeni bilgileri doğrulamak adına kendi adımlarımızı atabileceğimizi unutmayınız. Buna ek olarak, talep ettiğiniz her durumda silmenizi talep ettiğiniz kişisel verileri saklanmasına devam etmek i&ccedil;in makul bir yasal gerek&ccedil;emizin olduğunu d&uuml;ş&uuml;nmemiz durumunda silme zorunluluğumuz bulunmamaktadır. Talebinize size bu gerek&ccedil;enin ne olduğunu da bildirerek d&ouml;n&uuml;ş yapacağımızı bildiririz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bizimle <span style=\"color: #000000;\">dietlifee@gmail.com</span> e-posta adresi vasıtasıyla iletişime ge&ccedil;erek ve kişisel verilerinizin d&uuml;zeltilmesi ya da silinmesi talebinde bulunduğunuzu ve bu talebi hangi bilgi temelinde yaptığınızı bize bildirerek yapabilirsiniz. Doğru olmayan bilgileri yeni bilgiler ile değiştirmemizi istemeniz durumunda, yeni verinin ne olduğunu bize s&ouml;ylemeniz gerekmektedir. Bu t&uuml;r bir talepte bulunmak i&ccedil;in &ouml;zel bir form doldurmanıza gerek bulunmamaktadır.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">Verilerinizin İşlenmesini Sınırlama Hakkı</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Kişisel verilerinizi meşru bir &ccedil;ıkar temelinde işleme aldığımız durumlarda (l&uuml;tfen bu Politikanın kişisel verilerinizi nasıl ve neden kullandığımızı a&ccedil;ıklayan kısımlarına bakınız) verilerinizi işlemeye devam etmemizin temel haklarınızı ve &ouml;zg&uuml;rl&uuml;klerinizi etkilediğini d&uuml;ş&uuml;n&uuml;yor veya bu meşru &ccedil;ıkarların ge&ccedil;erli olmadığınız d&uuml;ş&uuml;n&uuml;yorsanız verilerinizin o şekilde işlenmesinin durdurulmasını talep etmek hakkına sahipsiniz.<br>Diet Life aşağıdaki şekillerde meşru bir &ccedil;ıkar temelinde verilerinizi işleyebilir:</p>"
  "<ul>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>&Uuml;r&uuml;nlerimizin i&ccedil;eriklerinin optimize edilmesi ve bunların teknik işlevlerinin geliştirilmesi;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>&Uuml;r&uuml;nlerimizin ve &Uuml;r&uuml;nlerde bulunan &ouml;zelliklerin pop&uuml;laritesinin değerlendirilmesi;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bir &Uuml;r&uuml;n&uuml;n işlevi ile ilgili olarak bir sorun tespit etmemiz durumunda tarafınıza teknik destek sağlanması;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>&Uuml;r&uuml;nler dahilindeki anti sosyal davranışların izlenmesi ve &ouml;nlenmesi;</li>"
  "<li style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Daha genel olarak; şirketimizin idaresi ve i&ccedil; işleyişimizin ger&ccedil;ekleşmesi ama&ccedil;ları ile.</li>"
  "</ul>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>(a) Kişisel verilerinizin doğruluğunun tartışmalı olması; (b) verilerinizin tarafımızca ger&ccedil;ekleştirilen kullanımının yasadışı olduğunun belirlenmesi ancak verilerin silinmesini istemiyor olmanız durumunda kişisel verilerinizi saklamayı durdurmamız veya verilerin doğruluğunu onaylamamızı; (c) kişisel verilerinizin işlenmesinin gerekli olmadığına (ve elden &ccedil;ıkarılmasının uygun olduğuna) karar vermemiz ancak yasal taleplerinizi tesis edebilmek, uygulayabilmek veya m&uuml;dafaa edebilmek i&ccedil;in saklanmasına devam edilmesini talep edebilirsiniz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>L&uuml;tfen herhangi bir gerek&ccedil;eyle işlenilmesinin durdurulmasını talep ettiğiniz kişisel verilerin işlenmesine devam etmek i&ccedil;in iyi bir yasal gerek&ccedil;enin olduğuna inanmamız durumunda; bu gerek&ccedil;enin ne olduğunu ya talebinize yanıt verirken ya da bunu d&uuml;ş&uuml;nme ve araştırma fırsatını edindikten sonra tarafınıza bildireceğiz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bizimle <span style=\"color: #000000;\">dietlifee@gmail.com</span> e-posta adresi vasıtasıyla iletişime ge&ccedil;erek bilgilerini kullanıp ulaşarak ve kişisel bilgilerinizin ilgili a&ccedil;ıdan işlenmesinin durdurulmasını talep ettiğinizi bildirerek ve yukarıdaki koşullardan hangisinin talebinizle ilgili olduğuna inandığınız belirerek kullanabilirsiniz. Bu t&uuml;r bir talepte bulunmak i&ccedil;in &ouml;zel bir form doldurmanıza gerek bulunmamaktadır.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">Taşınabilirlik Hakkı</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Otomatik y&ouml;ntemlerle işlenen ve hakkınız tuttuğumuz belirli kişisel verilerinizin &uuml;&ccedil;&uuml;nc&uuml; bir tarafa transfer edilmesini istemeniz durumunda bizimle irtibata ge&ccedil;ebilir ve bu verilerin genellikle kullanılan makinece okunabilir bir formatta size sağlanmasını talep edebilirsiniz. Yaptığımız işin t&uuml;r&uuml; ve kullandığımız sistem nedeniyle bu hakkın etkileşim halinde olduğumuz bireylerin &ccedil;oğu ile &ouml;zellikle ilgili olduğunu d&uuml;ş&uuml;nmemekteyiz. Ancak, verilerinizin b&uuml;nyemizden &uuml;&ccedil;&uuml;nc&uuml; bir tarafa transfer edilmesini istemeniz durumunda bu talebi dikkate almaktan memnuniyet duyarız.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">Mesaj almaktan vazge&ccedil;me hakkı</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Tarafınıza elektronik posta (ya da diğer elektronik mesajlar) yoluyla tanıtım mesajları g&ouml;nderiyor olmamız durumunda her daim bu abonelikten &ccedil;ıkma hakkınız bulunmaktadır. Bunu her mesajın sonunda g&ouml;r&uuml;n&uuml;n &quot;abonelikten &ccedil;ık&quot; bağlantısı (ya da bu t&uuml;r mesajlarda bulunan eşdeğer mekanizmalar) yoluyla yapabilirsiniz.<br>Alternatif olarak herhangi bir sebepten &ouml;t&uuml;r&uuml; bu bağlantıları kullanamıyor olmanız ya da bizimle doğrudan iletişime ge&ccedil;mek istemeniz durumunda <span style=\"color: #000000;\">dietlifee@gmail.com</span> adresini kullanarak ve hangi mesajları almak istemediğinizi belirterek de aboneliğinizi sonlandırabilirsiniz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">Otomatik karar alma ve profil &ccedil;ıkarmaya karşı &ccedil;ıkma hakkı</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Herhangi bir otomatik karar alma ya da kişisel verilerinizin profilinin &ccedil;ıkarılması hakkında ve uygun olduğu durumlarda sizi etkileyen bu işlemin &ouml;nemi ve &ouml;ng&ouml;r&uuml;len sonu&ccedil;larının yanı sıra arkasındaki mantık hakkında anlamlı bilgi edinme hakkına sahipsiniz.</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><span style=\"text-decoration: underline;\">Hakların kullanımı</span></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Haklarınızı kullanma talebi ile bizimle irtibata ge&ccedil;tiğinizde belirttiğiniz kişinin siz olduğunuzu kanıtlamanızı talep etme hakkına sahip olduğumuzu belirtiriz. Sizden kimliğinizin doğrulanması hususunda tarafımıza yardımcı olacak ilgili kimlik belgelerinin kopyalarını ibraz etmenizi talep edebiliriz. Hangi hakkınızı kullanmak istediğiniz ve ilgili olması durumunda neden kullandığınızı belirtmeniz talebinizi işleme almamızı kolaylaştıracaktır. Ne kadar net ve a&ccedil;ık olursanız talebiniz o kadar hızlı ve etkin bir bi&ccedil;imde ele alınır. Tarafımıza yeterli bilgi sunmamanız durumunda; yeterli bilgileri sunana kadar talebinizi işleme almakta gecikebiliriz (b&ouml;yle bir durum yaşanması durumunda tarafınıza bilgilendirme yapılacaktır).</p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'><strong>7. İletişim Detayları</strong></p>"
  "<p style='margin: 5px 0px; text-align: justify; font-stretch: normal; font-size: 13.5px; line-height: normal; font-family: \"Times New Roman\"; color: rgb(51, 51, 51);'>Bu Politika ile ilgili olarak herhangi bir sorunuzun olması, yukarıda tanımlanan haklarınızı kullanmak istemeniz ya da bu Politikaya riayet edilmediğini d&uuml;ş&uuml;nmeniz durumunda l&uuml;tfen <span style=\"color: #000000;\">dietlifee@gmail.com</span> adresi yoluyla bize ulaşınız.</p>"
  "<p><br></p>";

}