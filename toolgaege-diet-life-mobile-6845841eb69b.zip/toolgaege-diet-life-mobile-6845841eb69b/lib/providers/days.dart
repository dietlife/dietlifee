import 'package:dietlife/DB/DBHelper.dart';
import 'package:dietlife/providers/day.dart';
import 'package:dietlife/providers/user.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
class Days with ChangeNotifier{
  List<Day> _gunler = [
//    Day(
//      id: 'p1',
//      dayNumber: 1,
//      calori: 2300
//    ),
  ];

  final dbHelper = DatabaseHelper.instance;

  Future<void> fetchAndSetDay(String userId) async{
      var dayNumber =0;
      var firstDay = DateTime.now().toString();
      SharedPreferences prefs = await SharedPreferences.getInstance();
      if(prefs.getString('firstDay')==null){
        firstDay = DateTime.now().toString();
        prefs.setString('firstDay', firstDay.toString());
      }else{
        firstDay = prefs.getString('firstDay');
      }

      dayNumber = DateTime.now().difference(DateTime.parse(firstDay)).inDays;

      final List<Day> loadedProduct = [];
      var currentDate = DateTime.now();
      for(var i = 1;i<=16;i++){
        var date = DateTime(currentDate.year,currentDate.month,currentDate.day+i);
        var columnId = '${date.day}/${date.month}/${date.year}';
        final plan = await dbHelper.queryRows('$columnId&$userId');
        if(plan.isNotEmpty){
          loadedProduct.add(Day(id: plan[0]['id'], dayNumber: dayNumber+i, calori: plan[0]['calori'],date: date.toString()));
        }else{
          loadedProduct.add(Day(id: '', dayNumber: dayNumber+i, calori: 0,date: date.toString()));
        }
      }

      _gunler = loadedProduct;
       notifyListeners();
  }

  Future<void> updateDayFromPlans(String date,int id,int calori){

    var day = items.firstWhere((element) => element.date==date);
    day.id = id.toString();
    day.calori=calori;
    notifyListeners();

  }

  List<Day> get items {
    return [..._gunler];
  }

  Day findById(String id){
    return items.firstWhere((element) => element.id == id);
  }
}