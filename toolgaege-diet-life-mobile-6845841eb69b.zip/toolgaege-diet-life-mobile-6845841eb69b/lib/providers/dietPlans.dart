import 'package:dietlife/DB/DBHelper.dart';
import 'package:dietlife/providers/day.dart';
import 'package:dietlife/providers/dietPlan.dart';
import 'package:flutter/cupertino.dart';

class DietPlans with ChangeNotifier{
  List<DietPlan> _diyetler = [
//    Day(
//      id: 'p1',
//      dayNumber: 1,
//      calori: 2300
//    ),
  ];

  final dbHelper = DatabaseHelper.instance;

  Future<void> fetchAndSetDay() async{


//    final List<Day> loadedProduct = [];
//    var currentDate = DateTime.now();
//    for(var i = 0;i<30;i++){
//      var date = DateTime(currentDate.year,currentDate.month,currentDate.day+i);
//      final plan = await dbHelper.queryRows(date.toString());
//      if(plan.isNotEmpty){
//        loadedProduct.add(Day(id: plan[0]['id'], dayNumber: plan[0]['dayNumber'], calori: plan[0]['calori'],date: date.toString()));
//      }else{
//        loadedProduct.add(Day(id: '', dayNumber: 0, calori: 0,date: date.toString()));
//      }
//    }
//
//    _gunler = loadedProduct;
//    notifyListeners();
  }

  List<DietPlan> get diyetler {
    return [..._diyetler];
  }

  DietPlan findById(String id){
    return diyetler.firstWhere((element) => element.id == id);
  }
}

