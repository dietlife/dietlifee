
import 'dart:convert';

import 'package:dietlife/providers/constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

import 'meal.dart';

class Meals with ChangeNotifier{
  
  final String authToken;
  Meals(this.authToken);
  
  List<Meal> _meals =[];




  Future<void> fetchAndSetMeal() async{
    var url = '${Constants.url}/tarifler.json?auth=$authToken';
    try{
      final response = await http.get(url);
      final extractedData = json.decode(response.body) as Map<String, dynamic>;
      if(extractedData == null){
        return;
      }
      final List<Meal> loadedMeal = [];
      extractedData.forEach((mealId, mealData) {
        loadedMeal.add(Meal(
            id: mealId,
            tarif: mealData['tarif'],
            link: mealData['link'],
            title: mealData['title']
        ));
      });
      _meals = loadedMeal;
      notifyListeners();
    }catch(error){
      print(error);
      throw (error);
    }
  }
  

  List<Meal> get meals {
    return [..._meals];
  }
//  List<Meal> get faroriteItems{
//    return _meals.where((mealItem) => mealItem.isFavorite).toList();
//  }
  Meal findById(String id){
    return meals.firstWhere((element) => element.id == id);
  }
}