import 'package:flutter/cupertino.dart';

class DietPlan with ChangeNotifier{
  final String id;
  final int kalori;
  final List<List<String>> kahvalti;
  final List<List<String>> birinciAra;
  final List<List<String>> ogle;
  final List<List<String>> ikinciAra;
  final List<List<String>> aksam;
  final List<List<String>> ucuncuAra;

  DietPlan({
    this.id,
    this.kalori,
    this.kahvalti,
    this.birinciAra,
    this.ogle,
    this.ikinciAra,
    this.aksam,
    this.ucuncuAra
  });

}