//import 'dart:convert';
//
//import 'package:dietlife/providers/constants.dart';
//import 'package:dietlife/providers/user.dart';
//import 'package:flutter/cupertino.dart';
//import 'package:http/http.dart' as http;
//class CurrentUser with ChangeNotifier{
//
//  final String authToken;
//  final String userId;
//  List<User> _users;
//
//
//  CurrentUser(
//      this.authToken,
//      this.userId,
//      );
//
//
//
//  void updateUser (User user){
//    _users[0]=user;
//  }
//
//  Future<void> fetchAndSetUser() async{
//    final String filterString ='orderBy="id"&equalTo="$userId"';
//    var url = '${Constants.url}/users.json?auth=$authToken&$filterString';
//    try{
//      final response = await http.get(url);
//      final extractedData = json.decode(response.body) as Map<String, dynamic>;
//      if(extractedData == null){
//        return;
//      }
//
//
//      final List<User> loadedUser = [];
//      extractedData.forEach((userId, userData) {
//        print(userData);
//
//        loadedUser.add(User(
//          userData['id'],
//          userData['name'],
//          userData['surname'],
//          userData['email'],
//          userData['gender'],
//          userData['length'],
//          userData['heavy'],
//          userData['age'],
//          userData['aktivite'],
//          userData['zorluk'],
//          userData['istek'],
//        ));
//
//      });
//      _users = loadedUser;
//      //notifyListeners();
//    }catch(error){
//      throw (error);
//    }
//
//  }
//
//
//
//
//  List<User> get users {
//    return [..._users];
//  }
//
//}