import 'package:flutter/material.dart';


class YasalUyariScreen extends StatelessWidget {
  static const routeName = '/yasal-uyari-screen';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Yasal Uyarı'),
      ),
      body: 
      SingleChildScrollView(
          child:Padding(
            padding: EdgeInsets.all(20),
          child: Text(
              '   Bu uygulama kişileri bilgilendirmek amacıyla hazırlanmış olup, sağlık hizmeti vermemektedir. Uygulamadaki bilgiler hiçbir şekilde hastalıkların tanı veya tedavisinde kullanılmamalıdır. Uygulamada bulunan metin ve/veya görsel içerikler reklam amacı gütmemekte olup, ön bilgilendirme amacı taşımaktadır. Bu görsel ve/veya metin içerikler hiçbir tıbbi ya da evde uygulamaya dayanak oluşturmaz. Bu siteyi ziyaret eden kişiler yasal uyarı metninde yer alan hususları okumuş ve kabul etmiş sayılır.'
              '\n\n   Site içeriğinin bu şekilde tanı ve tedavi amacıyla kullanımından doğacak tüm sorumluluk ziyaretçiye, kullanıcıya aittir. Bu siteyi ziyaret eden kişiler bu uyarıları kabul etmiş sayılır.',
              style: TextStyle(fontSize: 18),
          ),
        )
        ),
    );
  }
}
