
import 'package:dietlife/DB/DBHelper.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/plans_screen.dart';
import 'package:dietlife/widgets/app_drawer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'PlannedPage.dart';

class  DayDetailScreen extends StatefulWidget {
  static const routeName = '/day-detail-screen';
  @override
  _DayDetailScreenState createState() => _DayDetailScreenState();
}

class _DayDetailScreenState extends State<DayDetailScreen> {



  final dbHelper = DatabaseHelper.instance;
  String dietProgram="";
  DateTime currentDate;
  bool isReady=false;

  List<String> aylar = [
    "Ocak",
    "Şubat",
    "Mart",
    "Nisan",
    "Mayıs",
    "Haziran",
    "Temmuz",
    "Ağustos",
    "Eylül",
    "Ekim",
    "Kasım",
    "Aralık",
  ];

  var date;
  var calori;
  var _isInit = true;
  @override
  void didChangeDependencies() async{

    if(_isInit){
      var data = ModalRoute.of(context).settings.arguments as List;
      date = data[0];
      calori = data[1];
      currentDate = DateTime.parse(date);
      _query(date);

    }
    _isInit = false;



    super.didChangeDependencies();
  }


  @override
  void initState() {



    super.initState();
  }

  void _query(String date) async {
    var userProvider = Provider.of<User>(context,listen: false);
    await userProvider.fetchAndSetUser();
    var userId = userProvider.userId;
    var columnId = '${DateTime.parse(date).day}/${DateTime.parse(date).month}/${DateTime.parse(date).year}';
    final plan = await dbHelper.queryRows('$columnId&$userId');
    print(plan[0]["plan"]);
    setState(() {
      dietProgram = plan[0]["plan"];
      isReady =true;
    });
  }


  @override
  Widget build(BuildContext context) {
    //PopupMenu.context = context;
    return Scaffold(
      appBar: AppBar(
        title: Text('${currentDate.day} ${aylar[currentDate.month-1]}'),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 15),
            child: GestureDetector(
                onTap: (){
                  Navigator.of(context).pushReplacementNamed(PlansScreen.routeName, arguments: [currentDate.toString(),calori]);
                },
                child: Icon(Icons.refresh)
            ),
          )
        ],
      ),
      body: Center(
        child:  Container(
//            Containerdecoration: BoxDecoration(
//              image: DecorationImage(
//                image: AssetImage("assets/images/paper.jpg"),
//                fit: BoxFit.fill,
//              ),
//            ),
            child: isReady?PlannedPage(dietProgram: dietProgram,):CircularProgressIndicator()
        ),
      ),
    );
  }
}