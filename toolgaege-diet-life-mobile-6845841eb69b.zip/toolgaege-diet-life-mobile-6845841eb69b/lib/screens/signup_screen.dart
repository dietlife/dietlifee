import 'dart:io';

import 'package:dietlife/providers/auth.dart';
import 'package:dietlife/screens/personel_info_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SignupScreen extends StatefulWidget {
  static const routeName = "/signup-screen";

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {


  Map<String, String> _authData = {
    'email': '',
    'password': '',
    'Adi':'',
    'Soyadi':'',
  };

  var _isLoading = false;

  void _showErrorDialog(String message){
    showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Bir sorun oluştu!'),
          content: Text(message),
          actions: [
            FlatButton(
              child: Text('Tamam'),
              onPressed: (){
                Navigator.of(ctx).pop();
              },
            )
          ],
        )
    );
  }

  void _submit() async{


    if(passwordController.text!=confirmController.text){
      _showErrorDialog('Şifreler uyuşmuyor');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    _authData['email'] = emailController.text;
    _authData['password']=passwordController.text;
    _authData['name']=nameController.text;
    _authData['surname']=surnameController.text;


    try{

      await Provider.of<Auth>(context,listen: false).signup(
          _authData['email'],
          _authData['password'],
          _authData['name'],
          _authData['surname'],

      );

    } on HttpException catch(error){
      var errorMessage = 'Oturum açma başarısız!';
      if(error.toString().contains('EMAIL_EXISTS')){
        errorMessage = 'Bu email kullanımda';
      }else if(error.toString().contains('INVALID_EMAIL')){
        errorMessage = 'Geçersiz bir E-posta adresi girdiniz';
      }else if(error.toString().contains('WEAK_PASSWORD')){
        errorMessage = 'Basit bir şifre girdiniz';
      }else if(error.toString().contains('EMAIL_NOT_FOUND')){
        errorMessage = 'Bu E-mail ile kullanıcı bulunamadı';
      }else if(error.toString().contains('INVALID_PASSWORD')){
        errorMessage = 'Geçersiz şifre';
      }

      _showErrorDialog(errorMessage);

    }catch(error){
      final errorMessage = 'Oturum açılamadı lütfen daha sonra tekrar deneyiniz}';
      print(error);
      _showErrorDialog(errorMessage);
    }


    setState(() {
      _isLoading = false;
    });
  }

  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmController = TextEditingController();
  var nameController = TextEditingController();
  var surnameController = TextEditingController();

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(16.0),
        height: double.infinity,
        decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [
                  Colors.lightGreen,
                  Colors.green
                ]
            )
        ),
        child: Column(
          children: <Widget>[
            Container(
                margin: const EdgeInsets.only(top: 40.0,bottom: 20.0),
                height: 80,
                child: Image.asset('assets/logo/logo.jpg')
            ),
            Text("DIETLIFE".toUpperCase(), style: TextStyle(
                color: Colors.white70,
                fontSize: 24.0,
                fontWeight: FontWeight.bold
            ),),
            SizedBox(height: 40.0),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.notes_outlined, color: Colors.lightGreen,)),
                hintText: "Adınız",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
            ),
            SizedBox(height: 10.0),
            TextField(
              controller: surnameController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.notes_outlined, color: Colors.lightGreen,)),
                hintText: "Soyadınız",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
            ),
            SizedBox(height: 10.0),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.person, color: Colors.lightGreen,)),
                hintText: "Email Adresiniz",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
            ),
            SizedBox(height: 10.0),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.lock, color: Colors.lightGreen,)),
                hintText: "Şifre giriniz",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
              obscureText: true,
            ),
            SizedBox(height: 10.0),
            TextField(
              controller: confirmController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.lock, color: Colors.lightGreen,)),
                hintText: "Şifrenizi Tekrar Giriniz",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
              obscureText: true,
            ),
            SizedBox(height: 30.0),
            if(_isLoading)
              CircularProgressIndicator()
            else
            SizedBox(
              width: double.infinity,
              child: RaisedButton(
                color: Colors.white,
                textColor: Colors.lightGreen,
                padding: const EdgeInsets.all(20.0),
                child: Text("KAYDOL".toUpperCase()),
                onPressed: (){
                  _submit();
                },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0)
                ),
              ),
            ),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                FlatButton(
                  textColor: Colors.white70,
                  child: Text("Oturum Aç".toUpperCase()),
                  onPressed: (){
                    Navigator.of(context).pop();
                  },
                ),
              ],),
            SizedBox(height: 10.0),
          ],
        ),
      ),
    );
  }
}