import 'package:dietlife/providers/current_user.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/dailyPlan.dart';
import 'package:dietlife/screens/managePlan.dart';
import 'package:dietlife/screens/purchase_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ZorlukScreen extends StatelessWidget {
  static const routeName = '/zorluk-screen';

  void submit(int zorluk,BuildContext context){
    Provider.of<User>(context,listen: false).setZorlukInfo(zorluk).then((value) => {
      Navigator.of(context).pushReplacementNamed(purchaseScreenNew.routeName)
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fiziksel Aktivite'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Container(height: 100,),
            Text(
              'ZORLUK SEVİSYESİNİ SEÇİNİZ',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Theme.of(context).primaryColor
              ),
            ),
            SizedBox(height: 70,),
            GestureDetector(
              onTap: (){
                submit(1, context);
              },
              child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                  ),
                  height: 100,
                  width: 300,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Center(
                          child: Text(
                            'KOLAY',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).primaryColor,
                                fontSize: 20
                            ),
                          )
                      ),
                    ],
                  )
              ),
            ),
            SizedBox(height: 10,),
            GestureDetector(
              onTap: (){
               submit(2, context);
              },
              child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                  ),
                  height: 100,
                  width: 300,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Center(
                          child: Text(
                            'ORTA',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).primaryColor,
                                fontSize: 20
                            ),
                          )
                      ),
                    ],
                  )
              ),
            ),
            SizedBox(height: 10,),
            GestureDetector(
              onTap: (){
                submit(3, context);
              },
              child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                  ),
                  height: 100,
                  width: 300,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Center(
                          child: Text(
                            'ZOR',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).primaryColor,
                                fontSize: 20
                            ),
                          )
                      ),
                    ],
                  )
              ),
            ),
          ],
        ),
      ),
    );


  }
}
