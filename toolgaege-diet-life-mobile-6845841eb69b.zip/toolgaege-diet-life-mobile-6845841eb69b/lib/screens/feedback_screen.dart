import 'package:flutter/material.dart';


class FeedBackScreen extends StatelessWidget {
  static const routeName = '/feed-back-screen';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Geri Bildirim'),
      ),
      body: Center(
        child: Text('Geri Bildirim Ekranı'),
      ),
    );
  }
}
