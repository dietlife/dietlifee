import 'package:flutter/material.dart';
// import 'package:getflutter/components/card/gf_card.dart';
// import 'package:getflutter/components/list_tile/gf_list_tile.dart';
import 'package:toast/toast.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'dailyPlan.dart';
class SportInfoScreen extends StatefulWidget {
  static const routeName = 'sport-info-screen';
  @override
  _SportInfoScreenState createState() => _SportInfoScreenState();
}

class _SportInfoScreenState extends State<SportInfoScreen> {
  final _controllerUyuma = TextEditingController();
  final _controllerBireyselBakim = TextEditingController();
  final _controllerYemekYeme = TextEditingController();
  final _controllerYemekPisirme = TextEditingController();
  final _controllerOturma = TextEditingController();
  final _controllerMasaBasi = TextEditingController();
  final _controllerEvIsi = TextEditingController();
  final _controllerTasitKullanim = TextEditingController();
  final _controllerYurume = TextEditingController();

  int toplamSaat = 0;
  List<TextEditingController> controllers = List<TextEditingController>();


  hourSubmit()async{
    if(toplamSaat != 24){
      Toast.show("Toplam saat 24 saat olmalıdır", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);
    }else{
      Navigator.of(context).pushReplacementNamed(DailyPlan.routeName);
      final prefs = await SharedPreferences.getInstance();
      prefs.setString('info', 'yapildi');
    }
  }


  updateHour(){
    print('asdfsd');
    if(controllers.length == 0){
      controllers.add(_controllerUyuma);
      controllers.add(_controllerBireyselBakim);
      controllers.add(_controllerYemekYeme);
      controllers.add(_controllerYemekPisirme);
      controllers.add(_controllerOturma);
      controllers.add(_controllerMasaBasi);
      controllers.add(_controllerEvIsi);
      controllers.add(_controllerTasitKullanim);
      controllers.add(_controllerYurume);
    }
    int toplam = 0;

    for(int i = 0; i<controllers.length;i++){
      if(controllers[i].text.isNotEmpty){
        toplam = toplam + int.parse(controllers[i].text);
      }
    }

    setState(() {
      toplamSaat = toplam;
    });

  }


  @override
  Widget build(BuildContext context) {


    return Scaffold(
      appBar: AppBar(
        title: Text("Günlük Aktivite Bilgisi"),
      ),
      body: Container(
        child: Column(
          children: [
            Expanded (
              child: ListView(
                children: [
                  Card(
                    // padding: EdgeInsets.all(1.0),
                    // boxFit: BoxFit.cover,
                    // title: GFListTile(
                    //   padding: EdgeInsets.all(1.0),
                    //   title: Text(
                    //     'Günlük Aktivite',
                    //     style: TextStyle(
                    //         fontSize: 20.0,
                    //         fontWeight: FontWeight.bold
                    //     ),
                    //   ),
                    // ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Divider(),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Günlük kaç saat uyuyorsun?",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _controllerUyuma,
                            keyboardType: TextInputType.number,
                            onChanged: (String val) => updateHour(),
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                suffixText: 'Saat'
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Günlük kişisel bakımınıza ayırdığınız vakit?",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _controllerBireyselBakim,
                            keyboardType: TextInputType.number,
                            onChanged: (String val) => updateHour(),
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                suffixText: 'Saat'
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Günlük kaç saat yemek yiyorsun?",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _controllerYemekYeme,
                            keyboardType: TextInputType.number,
                            onChanged: (String val) => updateHour(),
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                suffixText: 'Saat'
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Günlük kaç saat yemek pişiriyorsun?",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _controllerYemekPisirme,
                            onChanged: (String val) => updateHour(),
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                suffixText: 'Saat'
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Günlük kaç saat oturuyorsun?",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _controllerOturma,
                            onChanged: (String val) => updateHour(),
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                suffixText: 'Saat'
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Günlük kaç saat masa başında oturuyorsun?",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _controllerMasaBasi,
                            onChanged: (String val) => updateHour(),
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                suffixText: 'Saat'
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Günlük kaç saat ev işi yapıyorsun?",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _controllerEvIsi,
                            onChanged: (String val) => updateHour(),
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                suffixText: 'Saat'
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Günlük kaç saat araba kullanıyorsun?",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _controllerTasitKullanim,
                            onChanged: (String val) => updateHour(),
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                suffixText: 'Saat'
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Günlük kaç saat yürüyorsun?",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: TextFormField(
                            controller: _controllerYurume,
                            keyboardType: TextInputType.number,
                            onChanged: (String val) => updateHour(),
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                suffixText: 'Saat'
                            ),
                          ),
                        ),



                      ],
                    ),
                  ),
                ],
              ),
            ),
            Wrap(
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 12.0),
                    child: RaisedButton(
                      onPressed: () => hourSubmit(),
                      child:  Text('İleri - $toplamSaat/24', style: TextStyle(fontSize: 20)),
                      color: Colors.blue,
                      textColor: Colors.white,
                      elevation: 5,
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
