import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/gecmis_tarti_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:numberpicker/numberpicker.dart';
// import 'package:intl/intl.dart';
import 'package:toast/toast.dart';
class HakkimdaScreen extends StatefulWidget {
  static const routeName = '/hakkimda-screen';

  @override
  _HakkimdaScreenState createState() => _HakkimdaScreenState();
}

class _HakkimdaScreenState extends State<HakkimdaScreen> {

  List<String> aylar = [
    "Ocak",
    "Şubat",
    "Mart",
    "Nisan",
    "Mayıs",
    "Haziran",
    "Temmuz",
    "Ağustos",
    "Eylül",
    "Ekim",
    "Kasım",
    "Aralık",
  ];


  int boy = 0;
  double kilo = 0.0;
  String istek = '';
  String aktivite = '';
  String zorluk = '';
  int yas = 0;
  String cinsiyet = 'Erkek';
  int enerjiIhtiyaci = 0;
  int uygulananPlan = 0;
  String sonTarti = '';

  bool isLoading = false;
  var _isInit = true;
  @override
  void didChangeDependencies() async{

    setState(() {
      isLoading = true;
    });

    if(_isInit){
      var userProvider = Provider.of<User>(context,listen: false);
      await userProvider.fetchAndSetUser();
      boy = userProvider.length;
      kilo = userProvider.heavy;
      istek = userProvider.istek;
      zorluk = userProvider.zorluk;
      aktivite = userProvider.aktivite;
      yas = userProvider.age;
      cinsiyet = userProvider.gender;
      enerjiIhtiyaci = userProvider.getIhtiyac().round();
      uygulananPlan = userProvider.kaloriHesapla();
      sonTarti = userProvider.sonTarti;
    }
    _isInit = false;


    setState(() {
      isLoading = false;
    });
    super.didChangeDependencies();
  }

  String dogumGunu;
  _showYasSelector(BuildContext context) async{
    var currentYear = DateTime.now().year;
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2000), // Refer step 1
      firstDate: DateTime(1915),
      lastDate: DateTime(currentYear-18),
    );
    if (picked != null){
      var cYas = DateTime.now().year-picked.year;
      await Provider.of<User>(context,listen: false).setYasInfo(picked.toIso8601String());
      dogumGunu = picked.toIso8601String();
      setState(() {
        yas=cYas;
      });
    }

  }


  _showZorlukSelector(BuildContext context){
    showDialog(
        context: context,
        builder: (_) => new AlertDialog(
          title: new Text("Diyet Zorluk"),
          content:  SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Container(height: 100,),
                Text(
                  'ZORLUK SEVİSYESİNİ SEÇİNİZ',
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Theme.of(context).primaryColor
                  ),
                ),
                SizedBox(height: 70,),
                GestureDetector(
                  onTap: (){
                    Provider.of<User>(context,listen: false).setZorlukInfo(1);
                    setState(() {
                      zorluk = Provider.of<User>(context,listen: false).zorluk;
                    });
                    Navigator.of(context).pop();
                    Toast.show("Zorluk Seviyesi Bilgisi Güncellenmiştir", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);

                  },
                  child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                      ),
                      height: 100,
                      width: 300,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Center(
                              child: Text(
                                'KOLAY',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor,
                                    fontSize: 20
                                ),
                              )
                          ),
                        ],
                      )
                  ),
                ),
                SizedBox(height: 10,),
                GestureDetector(
                  onTap: (){
                    Provider.of<User>(context,listen: false).setZorlukInfo(2);
                    setState(() {
                      zorluk = Provider.of<User>(context,listen: false).zorluk;
                    });
                    Navigator.of(context).pop();
                    Toast.show("Zorluk Seviyesi Bilgisi Güncellenmiştir", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);

                  },
                  child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                      ),
                      height: 100,
                      width: 300,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Center(
                              child: Text(
                                'ORTA',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor,
                                    fontSize: 20
                                ),
                              )
                          ),
                        ],
                      )
                  ),
                ),
                SizedBox(height: 10,),
                GestureDetector(
                  onTap: (){
                    Provider.of<User>(context,listen: false).setZorlukInfo(3);
                    setState(() {
                      zorluk = Provider.of<User>(context,listen: false).zorluk;
                    });
                    Navigator.of(context).pop();
                    Toast.show("Zorluk Seviyesi Bilgisi Güncellenmiştir", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);

                  },
                  child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                      ),
                      height: 100,
                      width: 300,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Center(
                              child: Text(
                                'ZOR',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor,
                                    fontSize: 20
                                ),
                              )
                          ),
                        ],
                      )
                  ),
                ),
              ],
            ),
          ),
        ));
  }


  _showAvtiviteSelector(BuildContext context){
    showDialog(
        context: context,
        builder: (_) => new AlertDialog(
          title: new Text("Günlük Fiziksel Aktivite"),
          content:  SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Container(height: 100,),
                Text(
                  'GÜNLÜK FİZİKSEL AKTİVİTENİZ',
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Theme.of(context).primaryColor
                  ),
                ),
                SizedBox(height: 70,),
                GestureDetector(
                  onTap: (){
                    Provider.of<User>(context,listen: false).setAktiviteInfo(1);
                    setState(() {
                      aktivite = Provider.of<User>(context,listen: false).aktivite;
                    });
                    Navigator.of(context).pop();
                    Toast.show("Fiziksel Aktivite Bilgisi Güncellenmiştir", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);

                  },
                  child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Center(
                              child: Text(
                                'HAFİF DÜZEY AKTİVİTE',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor,
                                    fontSize: 20
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.all(15),
                            child: Text('* Ev kadınları, evde masa başı çalışanlar vb.',style: TextStyle(fontWeight: FontWeight.bold)),
                          )
                        ],
                      )
                  ),
                ),
                SizedBox(height: 10,),
                GestureDetector(
                  onTap: (){
                    Provider.of<User>(context,listen: false).setAktiviteInfo(2);
                    setState(() {
                      aktivite = Provider.of<User>(context,listen: false).aktivite;
                    });
                    Navigator.of(context).pop();
                    Toast.show("Fiziksel Aktivite Bilgisi Güncellenmiştir", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);

                  },
                  child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Center(
                              child: Text(
                                'ORTA DÜZEY AKTİVİTE',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor,
                                    fontSize: 20
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.all(15),
                            child: Text('* Haftada 3-4 gün spor yapanlar, bir iş yerinde çalışanlar vb.',style: TextStyle(fontWeight: FontWeight.bold),),
                          )
                        ],
                      )
                  ),
                ),
                SizedBox(height: 10,),
                GestureDetector(
                  onTap: (){
                    Provider.of<User>(context,listen: false).setAktiviteInfo(3);
                    setState(() {
                      aktivite = Provider.of<User>(context,listen: false).aktivite;
                    });
                    Navigator.of(context).pop();
                    Toast.show("Fiziksel Aktivite Bilgisi Güncellenmiştir", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);

                  },
                  child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Center(
                              child: Text(
                                'AĞIR FİZİKSEL AKTİVİTE',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).primaryColor,
                                    fontSize: 20
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.all(15),
                            child: Text('* Ciddi derecede egzersiz yapanlar, inşaat ve maden işçileri vb.',style: TextStyle(fontWeight: FontWeight.bold)),
                          )
                        ],
                      )
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  _showKiloSelector(BuildContext context){

    var fark = DateTime.now().difference(DateTime.parse(sonTarti)).inDays;
    print('fark : $fark');
    if(fark>14){
      showDialog(
          context: context,
          builder:  (BuildContext context) {
            return new NumberPickerDialog.decimal(
              minValue: 25,
              maxValue: 250,
              title: new Text("Kilonuzu giriniz"),
              initialDoubleValue: kilo,
            );
          }
      ).then((value) {
        if(value!=null){
          Provider.of<User>(context,listen: false).setKilo(value);
          setState(() {
            kilo=value;
            sonTarti = DateTime.now().toIso8601String();
          });
        }

      });
    }else{
      showDialog(
          context: context,
          builder: (_) => new AlertDialog(
            title: new Text("Tarti Günü Gelmedi!"),
            content:  Text('Sayın kullanıcımız. Tartı gününüze ${14-fark} gün kalmıştır.'),
            actions: <Widget>[
              FlatButton(
                child: Text('Tamam'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ));
    }


  }

  @override
  Widget build(BuildContext context) {
    TextStyle firstStyle = TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 18,
        color: Colors.black
    );

    TextStyle secondStyle = TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 18,
        color: Theme.of(context).primaryColor
    );


    return Scaffold(
      appBar: AppBar(
        title: Text('Hakkimda'),
      ),
      body: isLoading?Center(child: CircularProgressIndicator(),)
          :SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: 20,
              ),
              Divider(color: Theme.of(context).primaryColor,),
              GestureDetector(
                onTap: (){
                  // _showNameChangeDialog();
                },
                child: Container(
                  color: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Boy',style: firstStyle,),
                        Text('$boy',style: secondStyle,)
                      ],
                    ),
                  ),
                ),
              ),
              Divider(color: Theme.of(context).primaryColor,),
              GestureDetector(
                onTap: (){
                  _showKiloSelector(context);
                },
                child: Container(
                  color: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Kilo',style: firstStyle,),
                        FlatButton(
                          child: Text('Geçmiş Tartılar',style: TextStyle(color: Colors.blue),),
                          onPressed: (){
                            Navigator.of(context).pushNamed(GecmisTartiScreen.routeName);
                          },
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text('$kilo',style: secondStyle,),
                            Text('${DateTime.parse(sonTarti).day} ${aylar[DateTime.parse(sonTarti).month-1]}',style: secondStyle,)
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
              Divider(color: Theme.of(context).primaryColor,),
              GestureDetector(
                onTap: (){
                  // _showNameChangeDialog();
                },
                child: Container(
                  color: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('İstek',style: firstStyle,),
                        Text('$istek',style: secondStyle,)
                      ],
                    ),
                  ),
                ),
              ),
              Divider(color: Theme.of(context).primaryColor,),
              GestureDetector(
                onTap: (){
                 _showAvtiviteSelector(context);
                },
                child: Container(
                  color: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Fiziksel Aktivite',style: firstStyle,),
                        Text('$aktivite',style: secondStyle,)
                      ],
                    ),
                  ),
                ),
              ),
              Divider(color: Theme.of(context).primaryColor,),
              GestureDetector(
                onTap: (){
                  _showZorlukSelector(context);
                },
                child: Container(
                  color: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Zorluk',style: firstStyle,),
                        Text('$zorluk',style: secondStyle,)
                      ],
                    ),
                  ),
                ),
              ),
              Divider(color: Theme.of(context).primaryColor,),
              GestureDetector(
                onTap: (){
                 // _showYasSelector(context);
                },
                child: Container(
                  color: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Yaş',style: firstStyle,),
                        Text('$yas',style: secondStyle,)
                      ],
                    ),
                  ),
                ),
              ),
              Divider(color: Theme.of(context).primaryColor,),
              GestureDetector(
                onTap: (){
                  // _showNameChangeDialog();
                },
                child: Container(
                  color: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Cinsiyet',style: firstStyle,),
                        Text('$cinsiyet',style: secondStyle,)
                      ],
                    ),
                  ),
                ),
              ),
              Divider(color: Theme.of(context).primaryColor,),
              GestureDetector(
                onTap: (){
                  // _showNameChangeDialog();
                },
                child: Container(
                  color: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Günlük Enerji İhtiyacı',style: firstStyle,),
                        Text('$enerjiIhtiyaci kalori',style: secondStyle,)
                      ],
                    ),
                  ),
                ),
              ),
              Divider(color: Theme.of(context).primaryColor,),
              GestureDetector(
                onTap: (){
                  // _showNameChangeDialog();
                },
                child: Container(
                  color: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Uygulanan Plan',style: firstStyle,),
                        Text('$uygulananPlan kalori',style: secondStyle,)
                      ],
                    ),
                  ),
                ),
              ),
              Divider(color: Theme.of(context).primaryColor,),








            ],
          ),
        ),
    );
  }
}
