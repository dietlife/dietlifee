import 'dart:io';
import 'package:dietlife/providers/auth.dart';
import 'package:dietlife/providers/constants.dart';
import 'package:dietlife/screens/content/view/content_view.dart';
import 'package:dietlife/screens/home_screen.dart';
import 'package:toast/toast.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_html/flutter_html.dart';

class AuthScreen extends StatefulWidget {
  static final String path = "lib/src/pages/login/login5.dart";

  static const routeName='auth-screen';
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  Map<String, String> _authDataLogin = {
    'email': '',
    'password': '',
  };
  Map<String, String> _authData = {
    'email': '',
    'password': '',
    'Adi':'',
    'Soyadi':'',
  };
  var _isLoading = false;
  String authMode = 'login';
  bool agree = false;



  _showPasswordChangeDialog(BuildContext context){
    TextEditingController email = TextEditingController();


    showDialog(
        context: context,
        builder: (_) => new AlertDialog(
          title: new Text("Şifre Değiş"),
          content:  SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: email,
                  decoration: InputDecoration(
                      labelText: 'Email Adresiniz',
                      border: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10))
                      )
                  ),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('Onayla'),
              onPressed: () {
                Provider.of<Auth>(context,listen: false).sendEmail(email.text);
                Navigator.of(context).pop();
                Toast.show("Şifre Değişikliği İçin Email Gönderilmiştir", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);

              },
            ),
            FlatButton(
              child: Text('İptal'),
              onPressed: () {

                Navigator.of(context).pop();

              },
            ),
          ],
        ));
  }


  void _showPrivacyPolicy(){
    showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
      title: Text('Gizlilik Politikası'),
      content: SingleChildScrollView(
        child: Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(20),
                child: Center(
                  child: SingleChildScrollView(
                    child: Html(
                        data:Constants.pravicyPolicyTr
                    ),
                  ),
                ),
              )
            ]
        ),
      ),
      actions: [
        FlatButton(
          child: Text('Tamam'),
          onPressed: (){
            Navigator.of(ctx).pop();
          },
        )
      ],
    ),
    );
  }

  void _showErrorDialog(String message){
    showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Bir sorun oluştu!'),
          content: Text(message),
          actions: [
            FlatButton(
              child: Text('Tamam'),
              onPressed: (){
                Navigator.of(ctx).pop();
              },
            )
          ],
        )
    );
  }

  void _submitlogin() async{

    setState(() {
      _isLoading = true;
    });

    _authDataLogin['email'] = emailController.text;
    _authDataLogin['password']=passwordController.text;

    try{

      await Provider.of<Auth>(context,listen: false).login(_authDataLogin['email'], _authDataLogin['password']);
      Navigator.pushReplacementNamed(context, HomePage.routeName );
    } on HttpException catch(error){
      var errorMessage = 'Oturum açma başarısız!';
      if(error.toString().contains('EMAIL_EXISTS')){
        errorMessage = 'Bu email kullanımda';
      }else if(error.toString().contains('INVALID_EMAIL')){
        errorMessage = 'Geçersiz bir E-posta adresi girdiniz';
      }else if(error.toString().contains('WEAK_PASSWORD')){
        errorMessage = 'Basit bir şifre girdiniz';
      }else if(error.toString().contains('EMAIL_NOT_FOUND')){
        errorMessage = 'Bu E-mail ile kullanıcı bulunamadı';
      }else if(error.toString().contains('INVALID_PASSWORD')){
        errorMessage = 'Geçersiz şifre';
      }

      _showErrorDialog(errorMessage);

    }catch(error){
      final errorMessage = 'Oturum açılamadı lütfen daha sonra tekrar deneyiniz}';
      print('asdfs $error');
      _showErrorDialog(errorMessage);
    }
    setState(() {
      _isLoading = false;
    });
  }
  void _submit() async{


    if(passwordController.text!=confirmController.text){
      _showErrorDialog('Şifreler uyuşmuyor');
      return;
    }
    if(!agree){
      _showErrorDialog('Gizlilik politikasını kabul etmeniz gerekmektedir. ');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    _authData['email'] = emailController.text;
    _authData['password']=passwordController.text;
    _authData['name']=nameController.text;
    _authData['surname']=surnameController.text;


    try{

      await Provider.of<Auth>(context,listen: false).signup(
        _authData['email'],
        _authData['password'],
        _authData['name'],
        _authData['surname'],

      );

      Navigator.pushReplacementNamed(context, HomePage.routeName );

    } on HttpException catch(error){
      var errorMessage = 'Oturum açma başarısız!';
      if(error.toString().contains('EMAIL_EXISTS')){
        errorMessage = 'Bu email kullanımda';
      }else if(error.toString().contains('INVALID_EMAIL')){
        errorMessage = 'Geçersiz bir E-posta adresi girdiniz';
      }else if(error.toString().contains('WEAK_PASSWORD')){
        errorMessage = 'Basit bir şifre girdiniz';
      }else if(error.toString().contains('EMAIL_NOT_FOUND')){
        errorMessage = 'Bu E-mail ile kullanıcı bulunamadı';
      }else if(error.toString().contains('INVALID_PASSWORD')){
        errorMessage = 'Geçersiz şifre';
      }

      _showErrorDialog(errorMessage);

    }catch(error){
      final errorMessage = 'Oturum açılamadı lütfen daha sonra tekrar deneyiniz}';
      print(error);
      _showErrorDialog(errorMessage);
    }

    setState(() {
      _isLoading = false;
    });
  }


  Scaffold getLoginScreen(){
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(16.0),
        height: double.infinity,
        decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [
                  Colors.lightGreen,
                  Colors.green
                ]
            )
        ),
        child: Column(
          children: <Widget>[
            Container(
                margin: const EdgeInsets.only(top: 40.0,bottom: 20.0),
                height: 80,
                child: Image.asset('assets/logo/logo.png')
            ),
            Text("DIETLIFE".toUpperCase(), style: TextStyle(
                color: Colors.white70,
                fontSize: 24.0,
                fontWeight: FontWeight.bold
            ),),
            SizedBox(height: 40.0),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.person, color: Colors.lightGreen,)),
                hintText: "Email Adresiniz",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
            ),
            SizedBox(height: 10.0),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.lock, color: Colors.lightGreen,)),
                hintText: "Şifre giriniz",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
              obscureText: true,
            ),
            SizedBox(height: 30.0),
            if(_isLoading)
              CircularProgressIndicator()
            else
              SizedBox(
                width: double.infinity,
                child: RaisedButton(
                  color: Colors.white,
                  textColor: Colors.lightGreen,
                  padding: const EdgeInsets.all(20.0),
                  child: Text("Oturum Aç".toUpperCase()),
                  onPressed: (){
                    _submitlogin();
                  },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0)
                  ),
                ),
              ),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                FlatButton(
                  textColor: Colors.white70,
                  child: Text("Kaydol".toUpperCase()),
                  onPressed: (){
                    setState(() {
                      authMode='signUp';
                    });
                  },
                ),
                Container(
                  height: 20,
                  width: 2,
                  color: Colors.white,
                ),
                FlatButton(
                  textColor: Colors.white70,
                  child: Text("ŞİFREMİ SIFIRLA".toUpperCase()),
                  onPressed: (){
                    _showPasswordChangeDialog(context);

                  },
                ),
              ],
            ),
            SizedBox(height: 10.0),
          ],
        ),
      ),
    );
  }
  Scaffold getSignUpScreen(){
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(16.0),
        height: double.infinity,
        decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [
                  Colors.lightGreen,
                  Colors.green
                ]
            )
        ),
        child: Column(
          children: <Widget>[
            Container(
                margin: const EdgeInsets.only(top: 40.0,bottom: 20.0),
                height: 80,
                child: Image.asset('assets/logo/logo.png')
            ),
            Text("DIETLIFE".toUpperCase(), style: TextStyle(
                color: Colors.white70,
                fontSize: 24.0,
                fontWeight: FontWeight.bold
            ),),
            SizedBox(height: 40.0),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.notes_outlined, color: Colors.lightGreen,)),
                hintText: "Adınız",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
            ),
            SizedBox(height: 10.0),
            TextField(
              controller: surnameController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.notes_outlined, color: Colors.lightGreen,)),
                hintText: "Soyadınız",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
            ),
            SizedBox(height: 10.0),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.person, color: Colors.lightGreen,)),
                hintText: "Email Adresiniz",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
            ),
            SizedBox(height: 10.0),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.lock, color: Colors.lightGreen,)),
                hintText: "Şifre giriniz",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
              obscureText: true,
            ),
            SizedBox(height: 10.0),
            TextField(
              controller: confirmController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(16.0),
                prefixIcon: Container(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                    margin: const EdgeInsets.only(right: 8.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            bottomLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                            bottomRight: Radius.circular(10.0)
                        )
                    ),
                    child: Icon(Icons.lock, color: Colors.lightGreen,)),
                hintText: "Şifrenizi Tekrar Giriniz",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.1),
              ),
              obscureText: true,
            ),
            SizedBox(height: 30.0),
            if(_isLoading)
              CircularProgressIndicator()
            else
              SizedBox(
                width: double.infinity,
                child: RaisedButton(
                  color: Colors.white,
                  textColor: Colors.lightGreen,
                  padding: const EdgeInsets.all(20.0),
                  child: Text("KAYDOL".toUpperCase()),
                  onPressed: (){
                    _submit();
                  },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0)
                  ),
                ),
              ),
            Row(
              children: [
                Checkbox(
                  value: agree,
                  onChanged: (_){
                    setState(() {
                      agree = !agree;
                    });
                  },
                ),
                GestureDetector(
                  onTap: (){
                    // _showPrivacyPolicy();
                    Navigator.push(context,MaterialPageRoute(builder: (context) => ContentView()));
                  },
                  child: Text(
                    "Gizlilik Politikasını kabul ediyorum",
                    style: TextStyle(
                        color: Colors.white
                    ),
                  ),
                )
              ],
            ),

            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                FlatButton(
                  textColor: Colors.white70,
                  child: Text("Oturum Aç".toUpperCase()),
                  onPressed: (){
                    setState(() {
                      authMode='login';
                    });
                  },
                ),
              ],),
            SizedBox(height: 10.0),
          ],
        ),
      ),
    );
  }



  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmController = TextEditingController();
  var nameController = TextEditingController();
  var surnameController = TextEditingController();





  @override
  Widget build(BuildContext context){
    return authMode=='login'?getLoginScreen():getSignUpScreen();
  }
}