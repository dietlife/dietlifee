import 'package:dietlife/providers/auth.dart';
import 'package:dietlife/providers/constants.dart';
import 'package:dietlife/providers/current_user.dart';
import 'package:dietlife/providers/globals.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/dailyPlan.dart';
import 'package:dietlife/screens/personel_info_page.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
class HomePage extends StatefulWidget {
static const routeName='/home-page';
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {


  String status = 'ilk';
  bool isLoading = false;
  var _isInit = true;
  @override
  void didChangeDependencies() async{

    setState(() {
      isLoading = true;
    });

    if(_isInit){
      await Provider.of<Auth>(context,listen: false).refreshSession();
      final prefs = await SharedPreferences.getInstance();
      if(prefs.containsKey('info')){
        status = prefs.getString('info');
      }else{
        var userProvider = Provider.of<User>(context,listen: false);
       await userProvider.fetchAndSetUser();
        MyGlobals().userId = userProvider.userId;
        if(userProvider.zorluk!=null){
          status = 'info';
        }
      }
    }
    _isInit = false;


    setState(() {
      isLoading = false;
    });
    super.didChangeDependencies();
  }
  
  Scaffold getCircular(){
    return Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    //return isLoading?getCircular():DailyPlan();
    return isLoading?getCircular():status=='ilk'?PersonelInfoPage():DailyPlan();
  }
}
