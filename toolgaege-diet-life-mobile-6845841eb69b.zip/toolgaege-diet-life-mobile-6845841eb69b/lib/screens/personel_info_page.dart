


import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/fiziksel_activite_screen.dart';
import 'package:dietlife/screens/sport_info_screen.dart';
import 'package:flutter/material.dart';
import 'package:gender_selection/gender_selection.dart';
// import 'package:getflutter/components/card/gf_card.dart';
// import 'package:getflutter/components/list_tile/gf_list_tile.dart';
import 'package:numberpicker/numberpicker.dart';
import 'package:provider/provider.dart';
import 'package:toast/toast.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
class PersonelInfoPage extends StatefulWidget {
  static const routeName = '/personel-info-page';

  @override
  _PersonelInfoPageState createState() => _PersonelInfoPageState();
}

class _PersonelInfoPageState extends State<PersonelInfoPage> {

  String gender ="";
  int yas = 18;
  int boy = 170;
  double kilo = 70.0;
  String dogunGunu = DateTime(2000).toIso8601String();

  var bluePinkGradient = new LinearGradient(
      colors: [Colors.lightGreen,Colors.green],
      tileMode: TileMode.clamp,
      begin: Alignment.topLeft,
      end:Alignment.bottomRight,
      stops: [0.0,1.0]
  );

  _showBoySelector(BuildContext context){
    showDialog(
        context: context,
        builder:  (BuildContext context) {
          return new NumberPickerDialog.integer(
            minValue: 50,
            maxValue: 250,
            title: new Text("Boyunuzu giriniz"),
            initialIntegerValue: 170,
          );
        }
    ).then((value) {
      setState(() {
        boy=value;
      });
    });
  }



  _showKiloSelector(BuildContext context){
    showDialog(
        context: context,
        builder:  (BuildContext context) {
          return new NumberPickerDialog.decimal(
            minValue: 25,
            maxValue: 250,
            title: new Text("Kilonuzu giriniz"),
            initialDoubleValue: 70.0,
          );
        }
    ).then((value) {
      setState(() {
        kilo=value;
      });
    });
  }


  _showYasSelector(BuildContext context) async{
    var currentYear = DateTime.now().year;
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: DateTime(currentYear-18), // Refer step 1
      firstDate: DateTime(1915),
      lastDate: DateTime(currentYear-18),
    );
    if (picked != null){
      var cYas = DateTime.now().year-picked.year;
      dogunGunu = picked.toIso8601String();
      setState(() {
        yas=cYas;
      });
    }

  }


  infoSubmit() async{
    if(gender==''){
      Toast.show("Cinsiyet Seçmelisiniz", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);
      return;
    }
    await Provider.of<User>(context,listen: false).setPersonelInfo(gender.split('.')[1], boy, kilo, dogunGunu);
    Navigator.pushReplacementNamed(context, FizikselAktiviteScreen.routeName);
  }

  @override
  Widget build(BuildContext context) {

      TextStyle firstStyle = TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 18,
          color: Colors.black
      );

      TextStyle secondStyle = TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 18,
          color: Theme.of(context).primaryColor
      );
    return Scaffold(
      appBar: AppBar(
        title: Text("Kişisel Bilgiler"),
      ),
      body: Container(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                children: [
                  Card(
                    // padding: EdgeInsets.all(1.0),
                    // boxFit: BoxFit.cover,
                    // title: ListTile(
                    //   padding: EdgeInsets.all(1.0),
                    //   title: Text(
                    //     'Kişisel Bilgiler',
                    //     style: TextStyle(
                    //         fontSize: 20.0,
                    //         fontWeight: FontWeight.bold
                    //     ),
                    //   ),
                    // ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Divider(),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child:Text("Cinsiyet",style: TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold),),
                        ),
                        GenderSelection(
                          maleText: "Erkek", //default Male
                          femaleText: "Kadın", //default Female
                          linearGradient: bluePinkGradient,
                          selectedGenderIconBackgroundColor: Colors.indigo, // default red
                          checkIconAlignment: Alignment.centerRight,   // default bottomRight
                          selectedGenderCheckIcon: null, // default Icons.check
                          onChanged: (Gender sGender){
                            print(sGender);
                            gender = sGender.toString();

                          },
                          equallyAligned: true,
                          animationDuration: Duration(milliseconds: 400),
                          isCircular: true, // default : true,
                          isSelectedGenderIconCircular: true,
                          opacityOfGradient: 0.6,
                          padding: const EdgeInsets.all(3),
                          size: 120, //default : 120

                        ),
                        Container(height: 20,),
                        Divider(color: Theme.of(context).primaryColor,),
                        GestureDetector(
                          onTap: (){
                            _showBoySelector(context);
                          },
                          child: Container(
                            color: Colors.transparent,
                            child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('Boy',style: firstStyle,),
                                  Text('$boy',style: secondStyle,)
                                ],
                              ),
                            ),
                          ),
                        ),
                        Divider(color: Theme.of(context).primaryColor,),
                        GestureDetector(
                          onTap: (){
                            _showKiloSelector(context);
                          },
                          child: Container(
                            color: Colors.transparent,
                            child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('Kilo',style: firstStyle,),
                                  Text('$kilo',style: secondStyle,)
                                ],
                              ),
                            ),
                          ),
                        ),
                        Divider(color: Theme.of(context).primaryColor,),
                        GestureDetector(
                          onTap: (){
                           // _showYasSelector(context);
                            DatePicker.showDatePicker(context,
                                showTitleActions: true,
                                minTime: DateTime(DateTime.now().year-118, 1, 1),
                                maxTime: DateTime(DateTime.now().year-18, 12, 31),
                                onConfirm: (date) {
                                  print('confirm $date');
                                  var cYas = DateTime.now().year-date.year;
                                  dogunGunu = date.toIso8601String();
                                  setState(() {
                                    yas=cYas;
                                  });
                                }, currentTime: DateTime.now(), locale: LocaleType.tr);
                          },
                          child: Container(
                            color: Colors.transparent,
                            child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('Yaş',style: firstStyle,),
                                  Text('$yas',style: secondStyle,)
                                ],
                              ),
                            ),
                          ),
                        ),
                        Divider(color: Theme.of(context).primaryColor,),

                      ],
                    ),
                  ),
                ],
              ),
            ),
            Wrap(
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 12.0),
                    child: RaisedButton(
                      onPressed: () => infoSubmit(),
                      child:  Text('İleri', style: TextStyle(fontSize: 20)),
                      color: Colors.blue,
                      textColor: Colors.white,
                      elevation: 5,
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
