import 'package:dietlife/providers/current_user.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/istek_screeen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class FizikselAktiviteScreen extends StatelessWidget {
  static const routeName = '/fiziksel-aktivite-screen';

  void submit(int aktivite,BuildContext context){

    Provider.of<User>(context,listen: false).setAktiviteInfo(aktivite).then((value) => {
    Navigator.of(context).pushReplacementNamed(IstekScreen.routeName)
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fiziksel Aktivite'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Container(height: 100,),
            Text(
              'GÜNLÜK FİZİKSEL AKTİVİTENİZ',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Theme.of(context).primaryColor
              ),
            ),
            SizedBox(height: 70,),
            GestureDetector(
              onTap: (){
                submit(1,context);
              },
              child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                  ),
                  height: 100,
                  width: 300,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Center(
                          child: Text(
                            'HAFİF DÜZEY AKTİVİTE',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).primaryColor,
                              fontSize: 20
                            ),
                          )
                      ),
                      Container(
                          margin: EdgeInsets.all(15),
                          child: Text('* Ev kadınları, evde masa başı çalışanlar vb.',style: TextStyle(fontWeight: FontWeight.bold)),
                      )
                    ],
                  )
              ),
            ),
            SizedBox(height: 10,),
            GestureDetector(
              onTap: (){
                submit(2,context);
              },
              child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                  ),
                  height: 100,
                  width: 300,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Center(
                          child: Text(
                            'ORTA DÜZEY AKTİVİTE',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).primaryColor,
                                fontSize: 20
                            ),
                          )
                      ),
                      Container(
                        margin: EdgeInsets.all(15),
                        child: Text('* Haftada 3-4 gün spor yapanlar, bir iş yerinde çalışanlar vb.',style: TextStyle(fontWeight: FontWeight.bold),),
                      )
                    ],
                  )
              ),
            ),
            SizedBox(height: 10,),
            GestureDetector(
              onTap: (){
                submit(3,context);
              },
              child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                  ),
                  height: 100,
                  width: 300,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Center(
                          child: Text(
                            'AĞIR FİZİKSEL AKTİVİTE',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).primaryColor,
                                fontSize: 20
                            ),
                          )
                      ),
                      Container(
                        margin: EdgeInsets.all(15),
                        child: Text('* Ciddi derecede egzersiz yapanlar, inşaat ve maden işçileri vb.',style: TextStyle(fontWeight: FontWeight.bold)),
                      )
                    ],
                  )
              ),
            ),
          ],
        ),
      ),
    );


  }
}
