import 'package:dietlife/providers/days.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/purchase_screen.dart';
import 'package:dietlife/widgets/app_drawer.dart';
import 'package:dietlife/widgets/day_grid.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
class ManagePlan extends StatefulWidget {
  static const  routeName = '/managePlan';
  @override
  _ManagePlanState createState() => _ManagePlanState();
}

class _ManagePlanState extends State<ManagePlan> {


  var calori;

  bool isLoading = false;
  var _isInit = true;
  var odemeDurumu = false;
  var getOdemeDurumu = false;
  @override
  void didChangeDependencies() async{



    if(_isInit){
      setState(() {
        isLoading = true;
      });
      var userProvider = Provider.of<User>(context,listen: false);
      await userProvider.fetchAndSetUser();
      var userId = userProvider.userId;
      await Provider.of<Days>(context,listen: false).fetchAndSetDay(userId);
      await Provider.of<User>(context,listen:false).fetchAndSetUser();
      calori = Provider.of<User>(context,listen: false).kaloriHesapla();
      print('gelen kalori: $calori');
      print('gelen _odemeDurumu: ${userProvider.getOdemeDurumu}');
      getOdemeDurumu = userProvider.getOdemeDurumu !=null ? userProvider.getOdemeDurumu : false;
    }
    setState(() {
      isLoading = false;
      odemeDurumu = getOdemeDurumu;
    });
    _isInit = false;

    super.didChangeDependencies();
  }





  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    if(isLoading == true){
      return Container(
        color: Colors.white,
        child: Center(child: CircularProgressIndicator(),),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text('DİYET PLANLARI'),
      ),
      body: Container(
        child: Column(
          children: [
            FittedBox(
              fit: BoxFit.fill,
              child: Column(
                children: <Widget>[
                  SizedBox(height: 1, width: 1),
                  Image.asset("assets/images/diyet_ust.png")
                ],
              ),
            ),
            Divider(),
            Expanded(
                child: isLoading ? Center(child: CircularProgressIndicator(),) : DayGrid(calori)
            ),
          ],
        ),
      ),
      drawer: AppDrawer(),
    );

  }
}
