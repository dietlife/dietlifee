import 'package:dietlife/providers/meals.dart';
import 'package:dietlife/widgets/app_drawer.dart';
import 'package:dietlife/widgets/meal_grid.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class RecipeScreen extends StatefulWidget {
  static const routeName = 'recipe-screen';
  @override
  _RecipeScreenState createState() => _RecipeScreenState();
}

class _RecipeScreenState extends State<RecipeScreen> {

  var isLoading = false;
  var _isInit = true;
  @override
  void didChangeDependencies() async{



    if(_isInit){
      setState(() {
        isLoading = true;
      });
      await Provider.of<Meals>(context,listen: false).fetchAndSetMeal();
    }
    setState(() {
      isLoading = false;
    });
    _isInit = false;

    super.didChangeDependencies();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Basit Tarifler'),
      ),
      drawer: AppDrawer(),
      body: isLoading? Center(
          child: CircularProgressIndicator()
      ):MealGrid(),
    );
  }
}
