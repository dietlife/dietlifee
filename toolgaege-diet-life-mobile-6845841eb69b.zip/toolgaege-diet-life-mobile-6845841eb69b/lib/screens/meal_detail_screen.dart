import 'package:dietlife/providers/meals.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_html/flutter_html.dart';
class MealDetailScreen extends StatelessWidget {

  static const routeName = 'meal-detail-screen';

  @override
  Widget build(BuildContext context) {
    final productId = ModalRoute.of(context).settings.arguments as String;
    final loadedMeal = Provider.of<Meals>(context,listen: false).findById(productId);
    return Scaffold(
      appBar: AppBar(
          title: Text(loadedMeal.title)
      ),
      body: SingleChildScrollView(
        child: Column(
            children: <Widget>[
              Container(
                height: 300,
                width: double.infinity,
                child: Container(
                  child: Image.network(
                      loadedMeal.link,
                      fit:BoxFit.cover
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(20),
                child: Center(
                  child: SingleChildScrollView(
                    child: Html(
                      data:loadedMeal.tarif
                    ),
                  ),
                ),
              )
            ]
        ),
      ),
    );
  }
}
