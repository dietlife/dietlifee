import 'package:dietlife/DB/DBHelper.dart';
import 'package:dietlife/screens/content/view/content_view.dart';
import 'package:dietlife/screens/feedback_screen.dart';
import 'package:dietlife/screens/gizlilik_politikasi_screen.dart';
import 'package:dietlife/screens/hakkimda_screen.dart';
import 'package:dietlife/screens/hesap_screen.dart';
import 'package:dietlife/screens/iletisim_screen.dart';
import 'package:dietlife/screens/yasal_uyari_screen.dart';
import 'package:dietlife/widgets/app_drawer.dart';
import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  static const  routeName = '/profilePage';
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {

  final dbHelper = DatabaseHelper.instance;


  _sifirla() async{

    await dbHelper.dropTableIfExistsThenReCreate();

    showDialog(
        context: context,
        builder: (_) => new AlertDialog(
          title: new Text("Diyet Sıfırlama"),
          content:  Text('Diyetleriniz sıfırlanmıştır'),
          actions: [
            FlatButton(
              child: Text('Onayla'),
              onPressed: (){
                Navigator.of(context).pop();
              },
            )
          ],
        ));

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Column(
            children: <Widget>[
              Card(
                child: ListTile(
                  onTap: (){
                    Navigator.of(context).pushNamed(HesapScreen.routeName);
                  },
                  leading: Icon(Icons.account_circle,color: Theme.of(context).primaryColor,),
                  title: Text('Hesap'),
                  trailing: Icon(Icons.keyboard_arrow_right_rounded),
                ),
              ),
              Card(
                child: ListTile(
                  onTap: (){
                    Navigator.of(context).pushNamed(HakkimdaScreen.routeName);
                  },
                  leading: Icon(Icons.accessibility,color: Theme.of(context).primaryColor,),
                  title: Text('Hakkımda'),
                  trailing: Icon(Icons.keyboard_arrow_right_rounded),
                ),
              ),
              Card(
                child: ListTile(
                  leading: Icon(Icons.star_rate_outlined,color: Theme.of(context).primaryColor,),
                  title: Text('Bize oy ver'),
                  trailing: Icon(Icons.keyboard_arrow_right_rounded),
                ),
              ),
              Card(
                child: ListTile(
                  onTap: (){
                    Navigator.of(context).pushNamed(YasalUyariScreen.routeName);
                  },
                  leading: Icon(Icons.warning_amber_outlined,color: Theme.of(context).primaryColor,),
                  title: Text('Yasal uyarı'),
                  trailing: Icon(Icons.keyboard_arrow_right_rounded),
                ),
              ),
              Card(
                child: ListTile(
                  onTap: (){
                    // Navigator.of(context).pushNamed(GizlilikPolitikasiScreen.routeName);
                    Navigator.push(context,MaterialPageRoute(builder: (context) => ContentView()));
                  },
                  leading: Icon(Icons.remove_red_eye,color: Theme.of(context).primaryColor,),
                  title: Text('Gizlilik politikası'),
                  trailing: Icon(Icons.keyboard_arrow_right_rounded),
                ),
              ),
              Card(
                child: ListTile(
                  onTap: (){
                    Navigator.of(context).pushNamed(IletisimScreen.routeName);
                  },
                  leading: Icon(Icons.quick_contacts_mail_outlined,color: Theme.of(context).primaryColor,),
                  title: Text('İletişim'),
                  trailing: Icon(Icons.keyboard_arrow_right_rounded),
                ),
              ),
              Card(
                child: ListTile(
                  onTap: (){
                    _sifirla();
                  },
                  leading: Icon(Icons.delete,color: Theme.of(context).primaryColor,),
                  title: Text('Diyetleri Sıfırla'),
                  trailing: Icon(Icons.keyboard_arrow_right_rounded),
                ),
              ),
            ],
          ),
        ),
      ),
      drawer: AppDrawer(),
    );
  }
}
