
import 'package:dietlife/DB/DBHelper.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/hakkimda_screen.dart';
import 'package:dietlife/widgets/app_drawer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'PlannedPage.dart';

class  DailyPlan extends StatefulWidget {
  static const routeName = '/daily-plan';
  @override
  _DailyPlanState createState() => _DailyPlanState();
}

class _DailyPlanState extends State<DailyPlan> {



  final dbHelper = DatabaseHelper.instance;
  String dietProgram="";
  DateTime currentDate;
  bool isReady=false;
  bool isDayAvailable = false;

  List<String> aylar = [
    "Ocak",
    "Şubat",
    "Mart",
    "Nisan",
    "Mayıs",
    "Haziran",
    "Temmuz",
    "Ağustos",
    "Eylül",
    "Ekim",
    "Kasım",
    "Aralık",
  ];

  @override
  void initState() {


    currentDate = DateTime.now();
    _query(currentDate.toString());

    super.initState();
  }

  void _query(String date) async {
    var provider = await Provider.of<User>(context,listen: false);
        await provider.fetchAndSetUser();Provider.of<User>(context,listen: false).kaloriHesapla();
    var userId = provider.userId;
    print('buralara geldim');
    var columnId = '${DateTime.parse(date).day}/${DateTime.parse(date).month}/${DateTime.parse(date).year}';
    final plan = await dbHelper.queryRows('$columnId&$userId');
    if(plan.isNotEmpty){
      print('asdfa ${plan[0]["plan"]}');
      setState(() {
        dietProgram = plan[0]["plan"];
        isDayAvailable = true;
      });
    }else{
      print('bosmus ya yala');
      setState(() {
        isDayAvailable = false;
      });
    }

    setState(() {
      isReady = true;
    });

  }


  @override
  Widget build(BuildContext context) {
    //PopupMenu.context = context;
    return Scaffold(
      appBar: AppBar(
        title: Text('${DateTime.now().day} ${aylar[DateTime.now().month-1]}'),
      ),
      body: Center(
        child:  Container(
//            decoration: BoxDecoration(
//              image: DecorationImage(
//              //image: AssetImage("assets/images/paper.jpg"),
//              fit: BoxFit.fill,
//            ),
//            ),
            child: isReady?isDayAvailable? PlannedPage(dietProgram: dietProgram,):
                Center(
                  child: Text('Bugüne bir diyet atamadınız'),
                )
                :CircularProgressIndicator()
        ),
      ),
      drawer: AppDrawer(),
    );
  }
}