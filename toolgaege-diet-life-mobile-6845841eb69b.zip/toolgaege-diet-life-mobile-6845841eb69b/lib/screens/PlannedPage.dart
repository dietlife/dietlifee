
import 'package:dietlife/widgets/foodWidget.dart';
import 'package:dietlife/widgets/titleWidget.dart';
import 'package:flutter/material.dart';


class PlannedPage extends StatefulWidget {

  final String dietProgram;

  PlannedPage({this.dietProgram});

  @override
  PlannedPageState createState() => PlannedPageState();
}

class PlannedPageState extends State<PlannedPage> {



  List<Widget> dietList = List<Widget>();
  String dietProgram;




  @override
  void initState() {
    dietProgram = widget.dietProgram;
    print("ararg");
    print(dietProgram);
    super.initState();
  }


  Widget addDivider(){
    return Padding(
      padding: EdgeInsets.only(top: 20,bottom: 20),
      child: Divider(
        color: Colors.green,
        height: 8,
      ),
    );
  }


  getKahvalti(String kahvalti,List<Widget> dietList){

    dietList.add(TitleWidget(title: "Kahvaltı",popUpMenuItemsCount: 0));
    for(int i = 0;i<kahvalti.split("-").length-1;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:kahvalti.split("-")[i]));
    }



  }

  getBirAra(String birAra,List<Widget> dietList){
    dietList.add(addDivider());
    dietList.add(TitleWidget(title: "1. Ara",popUpMenuItemsCount: 0));
    for(int i = 0;i<birAra.split("-").length-1;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:birAra.split("-")[i]));
    }

  }

  getOgle(String ogle,List<Widget> dietList){
    dietList.add(addDivider());
    dietList.add(TitleWidget(title: "Öğle",popUpMenuItemsCount: 0));
    for(int i = 0;i<ogle.split("-").length-1;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:ogle.split("-")[i]));
    }
  }

  getIkiAra(String ikiAra,List<Widget> dietList){
    dietList.add(addDivider());
    dietList.add(TitleWidget(title: "2. Ara",popUpMenuItemsCount: 0));
    for(int i = 0;i<ikiAra.split("-").length-1;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:ikiAra.split("-")[i]));
    }
  }

  getAksam(String aksam,List<Widget> dietList){
    dietList.add(addDivider());
    dietList.add(TitleWidget(title: "Akşam",popUpMenuItemsCount: 0));
    for(int i = 0;i<aksam.split("-").length-1;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:aksam.split("-")[i]));
    }
  }

  getUcAra(String ucAra,List<Widget> dietList){
    dietList.add(addDivider());
    dietList.add(TitleWidget(title: "3. Ara",popUpMenuItemsCount: 0));
    for(int i = 0;i<ucAra.split("-").length-1;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:ucAra.split("-")[i]));
    }
  }



  List<Widget> getList(String content){
    dietList.clear();

    getKahvalti(content.split("||")[0],dietList);
    getBirAra(content.split("||")[1],dietList);
    getOgle(content.split("||")[2],dietList);
    getIkiAra(content.split("||")[3],dietList);
    getAksam(content.split("||")[4],dietList);
    getUcAra(content.split("||")[5],dietList);

    return dietList;

  }





  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: getList(dietProgram),
        ),
      ),
    );
  }
}
