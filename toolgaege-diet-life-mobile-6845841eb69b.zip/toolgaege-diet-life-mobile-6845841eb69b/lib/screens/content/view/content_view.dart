import 'package:dietlife/screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider/provider.dart';
// import 'package:flutter_base/src/models/auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:provider/provider.dart';
class ContentView extends StatefulWidget {
  static const routeName='/contentView';
  String id;
  ContentView({this.id});
  @override
  _ContentViewState createState() => _ContentViewState();
}

class _ContentViewState extends State<ContentView> {
// class contentView extends StatelessWidget {

  var _scaffoldKey = new GlobalKey<ScaffoldState>();
  String new_content;
  String lang;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Gizlilik Politikası'),
          leading: new IconButton(
            icon: new Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context, rootNavigator: true).maybePop(context);
            },
          ),
        ),
        backgroundColor: Colors.black,
        key: _scaffoldKey,
        body:  WebView(
          initialUrl: 'https://ahmtkaplan05.wixsite.com/dietlife/gizlilik-politikas%C4%B1',
          javascriptMode: JavascriptMode.unrestricted,
        )
    );

  }
}
