import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io' show Platform;
class IletisimScreen extends StatelessWidget {
  static const routeName = '/iletisim-screen';

  String s1 = 'Herkese merhaba,\n\n'+
  'Beslenme ile ilgili oluşturulmuş tüm uygulamalardan farklı bir program ile karşınızdayız. Programımız her kişinin özelliklerine göre (Boy, Yaş ve Cinsiyet vb.) özel diyet planı sunmaktadır. Diyet planı kişilerin sevdikleri yiyeceklere uygun seçenekler de içerir. Amacınız ister kilo alma olsun, ister kilo verme olsun.'
  'Pandemi süresince hepimizin beslenme alışkanlıkları büyük ölçüde değişti. Ben ve diyetisyen arkadaşlarım çoğu insanın beslenme stilini düzenlemek için diyetisyen desteği alamadığını fark ettik. İnsanlara daha uygun imkanlar ile beslenme desteği sağlayabilmek amacıyla bu programı oluşturduk. Bu uygulamamız ile evden çıkıp diyetisyene gidemeseniz bile beslenme alışkanlıklarınızı değiştiren sağlıklı bir diyet planı ile kilo verebilirsiniz ya da kilo alabilirsiniz.'
  'Diyetisyenlerimizden ek danışmanlık almak isterseniz';

  String s2 = ' WhatsApp';
  String s3 = ' hattı üzerinden ulaşabilirsiniz.';
  String s4 = 'Whatsapp iletişim: ';

  launchWhatsapp(String type) async{
    if(type == "wp"){
      var phone = "+905510580725";
      var whatsappUrl ="whatsapp://send?phone=$phone";
      launch(whatsappUrl);
    }else if(type == "ig"){
      var igurl ="https://www.instagram.com/diyetlife_/";
      launch(igurl);
    }else{
      var yturl ="https://www.youtube.com/channel/UCkfHWnT7dWtzwgcnlQ5VmeQ";
      launch(yturl);
    }

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(
      appBar: AppBar(
        title: Text('HAKKIMIZDA VE İLETİŞİM'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              alignment: Alignment.center,
              height: 200,
              width: double.infinity,
              child: Image.asset('assets/logo/logo.png'),
            ),
            Padding(
              padding: EdgeInsets.all(20),
              child: RichText(
                text: TextSpan(
                  children: <TextSpan>[
                    TextSpan(text: s1, style: TextStyle(fontSize: 17,color: Colors.black)),
                    TextSpan(text: s2, style: TextStyle(fontSize: 17,color: Colors.purple)),
                    TextSpan(text: s3, style: TextStyle(fontSize: 17,color: Colors.black)),
                   // TextSpan(text: s4, style: TextStyle(fontSize: 17,color: Colors.purple)),
                  ],
                ),
              ),
            ),
            Divider(color: Theme.of(context).primaryColor,),
            Column(
              children: [
                ListTile(
                  onTap: (){
                   launchWhatsapp("wp");
                  },
                  leading: Icon(MdiIcons.whatsapp),
                  title: Text('WhatsApp'),
                ),
                ListTile(
                  onTap: (){
                    launchWhatsapp("ig");
                  },
                  leading: Icon(MdiIcons.instagram),
                  title: Text('Instagram'),
                ),
                ListTile(
                  onTap: (){
                    launchWhatsapp("yt");
                  },
                  leading: Icon(MdiIcons.youtube),
                  title: Text('Youtube'),
                ),
                Container(height: 150,)
              ],
            ),
          ],
        ),
      )
    );
  }
}
