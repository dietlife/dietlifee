import 'package:dietlife/providers/current_user.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/zorluk_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class IstekScreen extends StatelessWidget {
  static const routeName = '/istek-screen';

  void submit(int istek,BuildContext context){

    Provider.of<User>(context,listen: false).setIstekInfo(istek).then((value) => {
    Navigator.of(context).pushReplacementNamed(ZorlukScreen.routeName)
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fiziksel Aktivite'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Container(height: 100,),
            Text(
              'NE İSTİYORSUNUZ?',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Theme.of(context).primaryColor
              ),
            ),
            SizedBox(height: 70,),
            GestureDetector(
              onTap: (){
                submit(1, context);
              },
              child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                  ),
                  height: 100,
                  width: 300,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Center(
                          child: Text(
                            'KİLO VERMEK',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).primaryColor,
                                fontSize: 20
                            ),
                          )
                      ),
                    ],
                  )
              ),
            ),
            SizedBox(height: 10,),
            GestureDetector(
              onTap: (){
               submit(2, context);
              },
              child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3,color: Theme.of(context).primaryColor)
                  ),
                  height: 100,
                  width: 300,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Center(
                          child: Text(
                            'KİLO ALMAK',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).primaryColor,
                                fontSize: 20
                            ),
                          )
                      ),
                    ],
                  )
              ),
            ),
          ],
        ),
      ),
    );


  }
}
