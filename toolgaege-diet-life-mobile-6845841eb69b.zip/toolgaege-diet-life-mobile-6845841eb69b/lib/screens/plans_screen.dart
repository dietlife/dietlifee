import 'dart:convert';

import 'package:dietlife/DB/DBHelper.dart';
import 'package:dietlife/providers/auth.dart';
import 'package:dietlife/providers/constants.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/widgets/Page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';


class  PlansScreen extends StatefulWidget {
  static const routeName='/plans-screen';
  @override
  _PlansScreenState createState() => _PlansScreenState();
}

class _PlansScreenState extends State<PlansScreen> {

  TextStyle customTS= TextStyle(fontSize: 16.0,color: Colors.black);
  final dbHelper = DatabaseHelper.instance;
  DateTime currentDate;
  DateTime currentDietDate;
  int selectedKahvalti;
  List<String> hamVeri = [];
  List<List<Widget>> allWisgets = [];
  List<Widget> dietListAlt = [];
  List<GlobalKey<DietPageState>> keyList = [];
  List<String> days =[];
  int currentSelectedDateIndex;
  bool isLoading = false;


  List<String> aylar = [
    "Ocak",
    "Şubat",
    "Mart",
    "Nisan",
    "Mayıs",
    "Haziran",
    "Temmuz",
    "Ağustos",
    "Eylül",
    "Ekim",
    "Kasım",
    "Aralık",
  ];



  static final GlobalKey<ScaffoldState> _scaffoldKey =
  GlobalKey<ScaffoldState>();
  final controller = PageController(
    initialPage: 0,
  );
  var scrollDirection = Axis.horizontal;
  var actionIcon = Icons.swap_vert;
  List<DietPage> pagess =[];
  List<DietPage> finalListt = [];


  setScreen(){
    pagess.clear();
    finalListt.clear();
    for(int i=0;i<hamVeri.length;i++){
      final GlobalKey<DietPageState> dietPageKey = GlobalKey<DietPageState>();
      keyList.add(dietPageKey);
      pagess.add(DietPage(key: dietPageKey,dietProgram: hamVeri[i]));
    }
    setState(() {
      finalListt = pagess;
      isLoading = false;
    });
  }

  var date;
  int calori = 7;
  var _isInit = true;
  @override
  void didChangeDependencies() async{


    if(_isInit){
      var data = ModalRoute.of(context).settings.arguments as List;
      date = data[0];
      calori = data[1];
      var auth = Provider.of<Auth>(context,listen:false).token;
      currentSelectedDateIndex = 0;
      selectedKahvalti = 0;
      currentDate = DateTime.now();
      setState(() {
        isLoading = true;
        currentDietDate = DateTime(currentDate.year,currentDate.month,currentDate.day+1);
        finalListt.clear();
      });
      final String filterString = 'orderBy="kalori"&equalTo="$calori"';
      print('aranacak kalori: $calori');
      print('aranacak kalori: $date');
      final url = '${Constants.url}/diyetler.json?auth=$auth&$filterString';

      try{
        final response = await http.get(url);
        final extractedData = json.decode(response.body) as Map<String, dynamic>;
        if(extractedData == null){
          return;
        }

        extractedData.forEach((prodId, prodData) {
          hamVeri.add(prodData['liste']);
        });

        setScreen();
      }catch(error){

      }

    }
    _isInit = false;

    for(int i=1;i<=7;i++){
      checkAvailable(DateTime(currentDate.year,currentDate.month,currentDate.day+i));
    }


    super.didChangeDependencies();
  }

  checkAvailable(DateTime dateTime) async{
    final allRows = await dbHelper.queryRows(dateTime.toString());
    if(allRows.length==0){
      days.add("false");
    }else{
      days.add("true");
    }

  }

  _showCupertinoDialog() {
    showDialog(
        context: context,
        builder: (_) => new CupertinoAlertDialog(
          content: new Text("Diyetiniz Kaydedilmiştir"),
          actions: <Widget>[
            FlatButton(
              child: Text('Tamam'),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
            )
          ],
        ));
  }

  applyPlan()async{

    var provider = await Provider.of<User>(context,listen:false);
    await provider.fetchAndSetUser();
    var userId = provider.userId;
    print('userid: $userId');
    keyList[controller.page.toInt()].currentState.buildDay(currentDietDate,userId);
    setState(() {
      days[currentSelectedDateIndex] = "true";
    });
    _showCupertinoDialog();
  }

  @override
  Widget build(BuildContext context) {
    currentDietDate = DateTime.parse(date);
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('${currentDietDate.day} ${aylar[currentDietDate.month-1]}'),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 15),
            child: GestureDetector(
              child: Icon(Icons.save,),
              onTap: applyPlan,
            ),
          )
        ],
      ),
      body: isLoading?
      Container(
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                  'Size en uygun diyetler oluşturuluyor.',
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              Padding(
                child: CircularProgressIndicator(),
                padding: EdgeInsets.only(top: 20),
              )
            ],
          ),
        ),
      )
          :Container(
        child: Column(
          children: [
            Expanded(
              child: Center(
                child:  Container(
                  decoration: BoxDecoration(
                      color: Colors.white
//                    image: DecorationImage(
//                      image: AssetImage("assets/images/paper.jpg"),
//                      fit: BoxFit.fill,
//                    ),
                  ),
                  child: PageView(
                      controller: controller,
                      scrollDirection: scrollDirection,
                      pageSnapping: true,
                      children: finalListt
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}