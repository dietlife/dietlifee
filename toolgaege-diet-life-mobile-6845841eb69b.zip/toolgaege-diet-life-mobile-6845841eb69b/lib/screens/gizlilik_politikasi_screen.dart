import 'package:dietlife/providers/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';


class GizlilikPolitikasiScreen extends StatelessWidget {
  static const routeName = '/gizlilik-politikasi-screen';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gizlilik Politikası'),
      ),
      body: SingleChildScrollView(
        child: Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(20),
                child: Center(
                  child: SingleChildScrollView(
                    child: Html(
                        data:Constants.pravicyPolicy
                    ),
                  ),
                ),
              )
            ]
        ),
      )
      );
  }
}
