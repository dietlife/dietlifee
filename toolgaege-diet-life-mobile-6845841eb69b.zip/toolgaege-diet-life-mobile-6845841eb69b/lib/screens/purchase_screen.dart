import 'dart:async';
import 'dart:io';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/content/view/content_view.dart';
import 'package:dietlife/screens/home_screen.dart';
import 'package:dietlife/screens/managePlan.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase/store_kit_wrappers.dart';
import 'package:dietlife/services/purchase_service.dart';
import '../main.dart';
import 'package:shared_preferences/shared_preferences.dart';
// import 'package:dietlife/widgets/purchase_button.dart';
import 'package:provider/provider.dart';
const bool kAutoConsume = true;

const String _kConsumableId = '';
const String _kSubscriptionId = '';
const List<String> _kProductIds = <String>[
  _kConsumableId,
  'noadforfifteendays',
  _kSubscriptionId
];

// TODO: Please Add your android product ID here
const List<String> _kAndroidProductIds = <String>[
  'diyetlife_' 
];
//Example
//const List<String> _kAndroidProductIds = <String>[
//  'ADD_YOUR_ANDROID_PRODUCT_ID_1',
//  'ADD_YOUR_ANDROID_PRODUCT_ID_2',
//  'ADD_YOUR_ANDROID_PRODUCT_ID_3'
//];

// TODO: Please Add your iOS product ID here
const List<String> _kiOSProductIds = <String>[
  // 'apple_aylik12',
  // '1_aylik_apple',
  // '3_aylik_apple',
  // '6_aylik_apple',
  'aylik_apple_1',
];
//Example
//const List<String> _kiOSProductIds = <String>[
//  'ADD_YOUR_IOS_PRODUCT_ID_1',
//  'ADD_YOUR_IOS_PRODUCT_ID_2',
//  'ADD_YOUR_IOS_PRODUCT_ID_3'
//];

class purchaseScreenNew extends StatefulWidget {
  static const routeName='/purchaseScreen';
  @override
  _purchaseScreenNewState createState() => _purchaseScreenNewState();
}

class _purchaseScreenNewState extends State<purchaseScreenNew> {
  final InAppPurchaseConnection _connection = InAppPurchaseConnection.instance;
  StreamSubscription<List<PurchaseDetails>> _subscription;
  List<String> _notFoundIds = [];
  List<ProductDetails> _products = [];
  List<PurchaseDetails> _purchases = [];
  List<String> _consumables = [];
  bool isAvailable = false;
  bool _purchasePending = false;
  bool _loading = true;
  String _queryProductError;
  bool isPremium = false;

  @override
  void initState() {

    satinAlmaPref();
    DateTime currentDate = DateTime.now();
    DateTime noADDate;

    var fiftyDaysFromNow = currentDate.add(new Duration(days: 30));
    print('${fiftyDaysFromNow.month} - ${fiftyDaysFromNow.day} - ${fiftyDaysFromNow.year} ${fiftyDaysFromNow.hour}:${fiftyDaysFromNow.minute}');

    Stream purchaseUpdated =
        InAppPurchaseConnection.instance.purchaseUpdatedStream;
    _subscription = purchaseUpdated.listen((purchaseDetailsList) {
      _listenToPurchaseUpdated(purchaseDetailsList);
    }, onDone: () {
      _subscription.cancel();
    }, onError: (error) {
      // handle error here.
    });
    initStoreInfo();
    super.initState();
  }


  @override
  void odemeSorgula(bool odeme) async{
    var userProvider = Provider.of<User>(context,listen: false);
    await userProvider.setOdemeDurumu(odeme);
    print('gelen _odemeDurumu: ${userProvider.getOdemeDurumu}');
  }



  Future<void> satinAlmaPref () async{
    prefs = await SharedPreferences.getInstance();
  }

  Future<void> initStoreInfo() async {
    final bool isAvailableStore = await _connection.isAvailable();

    if (!isAvailableStore) {
      setState(() {
        isAvailable = isAvailableStore;
        _products = [];
        _purchases = [];
        _notFoundIds = [];
        _consumables = [];
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    ProductDetailsResponse productDetailResponse =
    await _connection.queryProductDetails(Platform.isIOS ? _kiOSProductIds.toSet() : _kAndroidProductIds.toSet());//_kProductIds.toSet());
    if (productDetailResponse.error != null) {
      setState(() {
        _queryProductError = productDetailResponse.error.message;
        isAvailable = isAvailableStore;
        _products = productDetailResponse.productDetails;
        _purchases = [];
        _notFoundIds = productDetailResponse.notFoundIDs;
        _consumables = [];
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    if (productDetailResponse.productDetails.isEmpty) {
      setState(() {
        _queryProductError = null;
        isAvailable = isAvailableStore;
        _products = productDetailResponse.productDetails;
        _purchases = [];
        _notFoundIds = productDetailResponse.notFoundIDs;
        _consumables = [];
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    final QueryPurchaseDetailsResponse purchaseResponse =
    await _connection.queryPastPurchases();
    if (purchaseResponse.error != null) {
      // handle query past purchase error..
    }
    final List<PurchaseDetails> verifiedPurchases = [];
    for (PurchaseDetails purchase in purchaseResponse.pastPurchases) {
      if (await _verifyPurchase(purchase)) {
        verifiedPurchases.add(purchase);
      }
    }
    List<String> consumables = await ConsumableStore.load();
    setState(() {
      isAvailable = isAvailableStore;
      _products = productDetailResponse.productDetails;
      _purchases = verifiedPurchases;
      // print('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasasasasasasasasasasaasas\nassasasasasasasasasasasasa' + verifiedPurchases.toString());
      _notFoundIds = productDetailResponse.notFoundIDs;
      _consumables = consumables;
      _purchasePending = false;
      _loading = false;
    });
  }

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> stack = [];
    if (_queryProductError == null) {
      stack.add(
        Column(
          children: [
            _buildConnectionCheckTile(),
              buildProductList(),
            // _buildConsumableBox(),
          ],
        ),
      );
    } else {
      stack.add(Center(
        child: Text(_queryProductError),
      ));
    }
    if (_purchasePending) {
      stack.add(
          Container(
            margin: EdgeInsets.only(top:20),
            child: Center(
              child: CircularProgressIndicator(),
            ),
          )
      );
    }

    return Scaffold(
        appBar: AppBar(
          title: Text('Satın Alma Ekranı'),
          leading: new IconButton(
            icon: new Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pushReplacementNamed(context, HomePage.routeName );
            },
          ),
        ),

      body: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              height: 25,
            ),
            Container(
              child: Column(
                children: stack,
              ),
            ),
            SizedBox(
              height: 25,
            ),
            Container(
              child: InkWell(
                onTap: () {
                  // Navigator.of(context).pushReplacementNamed(ContentView.routeName);
                  Navigator.push(context,MaterialPageRoute(builder: (context) => ContentView()));
                },
                child: Text("Gizlilik Politikası",
                  style: TextStyle(
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 25,
            ),
            Text(
              "Premium içeriği",
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 25,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              padding: EdgeInsets.all(5),
              height: 450,
              width: 300,
              child: SingleChildScrollView(
                child: Text(
                    """✔️ Diyetisyene gitmenize gerek kalmadan çok rahat bir şekilde kilolarınızdan kurtulabileceksiniz.
  ✔️Herhangi bir sıkıntınızda WHATSAPP destek hattımız üzerinden alanında uzman diyetisyenlere ücretsiz bir şekilde danışarak yanıtsız sorunuz kalmayacak.
  ✔️Sizin antropometrik verilerinize göre (kilo, boy, cinsiyet, vb.) size özel oluşturulmuş diyet planı sayesinde kilolarınıza elveda diyeceksiniz.\n\n
KİLO KAYBI GARANTİSİ VERİYOR MU ?
KESİNLİKLE EVET. Şuana kadar programı kullanan yüzlerce insan gibi sizde çok rahat bir şekilde kilo verebileceksiniz
GÜVENLİ Mİ ?
Program tamamen bilimsel verilerin ışığında yapıldığı için % 100 güvenilirdir.
"""),
              ),
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(
                      width: 3, color: Theme.of(context).primaryColor)),
            )
          ],
        ),
      )
    );
  }

  Widget _buildConnectionCheckTile() {
    if (_loading) {
      return Text('');
    }
    final Widget storeHeader = Column(
     children: [
       // Icon(isAvailable ? Icons.check : Icons.block,
       //     color: isAvailable ? Colors.green : ThemeData.light().errorColor),
       // Text(
       //     'Mağaza ' + (isAvailable ? 'müsait' : 'kullanım dışı') + '.'),
     ],
    );
    final List<Widget> children = <Widget>[
      storeHeader
    ];

    if (!isAvailable) {
      children.addAll([
        Divider(),
        Column(
         children: [
           Text('Bağlı değil',
               style: TextStyle(color: ThemeData.light().errorColor)),
           Text(
               'Ödeme işlemcisine bağlanılamıyor. Tekrar Deneyin!'),
         ],
        ),
      ]);
    }
    return Column(children: children);
  }


  Widget buildProductList() {
    if (_loading) {
      return Container(
        width: MediaQuery.of(context).size.width,
        child: Column(
          children: [
            CircularProgressIndicator(),
            // Text('Ürünler getiriliyor...')
          ],
        ),
      );
    }
    // if (!isAvailable) {
    //   return Card();
    // }
    final ListTile productHeader = ListTile(title: Text('Satılık Ürünler'));
    List<Widget> productList = <Widget>[];




    if (_notFoundIds.isNotEmpty) {
      productList.add(
          Container(
            width: MediaQuery.of(context).size.width,
            child: Column(
              children: [
                Text('[${_notFoundIds.join(", ")}] bulunamadı',style: TextStyle(color: ThemeData.light().errorColor)),
                Text('Bir sorunla karşılaşdık! Sonra tekrar deneyin.')
              ],
            ),
          )
      );
    }

    // This loading previous purchases code is just a demo. Please do not use this as it is.
    // In your app you should always verify the purchase data using the `verificationData` inside the [PurchaseDetails] object before trusting it.
    // We recommend that you use your own server to verity the purchase data.
    Map<String, PurchaseDetails> purchases =
    Map.fromEntries(_purchases.map((PurchaseDetails purchase) {
      if (purchase.pendingCompletePurchase) {
        InAppPurchaseConnection.instance.completePurchase(purchase);
      }
      return MapEntry<String, PurchaseDetails>(purchase.productID, purchase);
    }));



    productList.addAll(_products.map(
          (ProductDetails productDetails) {
        PurchaseDetails previousPurchase = purchases[productDetails.id];
        prefs.setBool('isPremium', previousPurchase != null
            ? true : false);
        return Container(
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 50,),
                  Text(
                    "${productDetails.title}",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(height: 10,),
              previousPurchase != null
                  ? Icon(Icons.check)
                  :  Container(
                height: 50,
                width: 180,
                child: RaisedButton(
                  color: Colors.lightGreen,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                  onPressed: () async {
                    PurchaseParam purchaseParam = PurchaseParam(
                        productDetails: productDetails,
                        applicationUserName: null,
                        sandboxTesting: false);
                    if (productDetails.id == _kConsumableId) {
                      _connection.buyConsumable(
                          purchaseParam: purchaseParam,
                          autoConsume: kAutoConsume || Platform.isIOS);
                    } else {
                      _connection.buyNonConsumable(
                          purchaseParam: purchaseParam);
                    }
                  },
                  child: Text(
                    "Satın Al",
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              SizedBox(height: 10,),
              Text(
                "Fiyat : ${productDetails.price}",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.normal),
              ),
              SizedBox(height: 10,),
              Text(
                "Periot : ${productDetails.skProduct.subscriptionPeriod.numberOfUnits} Ay",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.normal),
              ),
            ],
          )
        );



      },
    ));

    return Column(
        children: productList
    );
  }

  Card _buildConsumableBox() {
    if (_loading) {
      return Card(
          child: ListTile(
              leading: CircularProgressIndicator(),
              title: Text('Paketler getiriliyor...')
          )
      );
    }
    if (!isAvailable || _notFoundIds.contains(_kConsumableId)) {
      return Card();
    }
    // final ListTile consumableHeader =
    // ListTile(title: Text('Satın Alınan Paket'));
    // final List<Widget> tokens = _consumables.map((String id) {
    //   return GridTile(
    //     child: IconButton(
    //       icon: Icon(
    //         Icons.stars,
    //         size: 42.0,
    //         color: Colors.orange,
    //       ),
    //       splashColor: Colors.yellowAccent,
    //       onPressed: () => consume(id),
    //     ),
    //   );
    // }).toList();
    return Card(
        child: Column(children: <Widget>[
          // consumableHeader,
          // Divider(),
          // GridView.count(
          //   crossAxisCount: 5,
          //   children: tokens,
          //   shrinkWrap: true,
          //   padding: EdgeInsets.all(16.0),
          // )
        ])
    );
  }

  Future<void> consume(String id) async {
    print('consume id is $id');
    await ConsumableStore.consume(id);
    final List<String> consumables = await ConsumableStore.load();
    setState(() {
      _consumables = consumables;
    });
  }

  void showPendingUI() {
    setState(() {
      _purchasePending = true;
    });
  }

  void deliverProduct(PurchaseDetails purchaseDetails) async {
    print('deliverProduct'); // Last
    // IMPORTANT!! Always verify a purchase purchase details before delivering the product.
    if (purchaseDetails.productID == _kConsumableId) {
      await ConsumableStore.save(purchaseDetails.purchaseID);
      List<String> consumables = await ConsumableStore.load();
      setState(() {
        _purchasePending = false;
        _consumables = consumables;
      });
    } else {
      setState(() {
        _purchases.add(purchaseDetails);
        _purchasePending = false;
      });
    }
  }

  void handleError(IAPError error) {
    setState(() {
      _purchasePending = false;
    });
  }

  Future<bool> _verifyPurchase(PurchaseDetails purchaseDetails) {
    // IMPORTANT!! Always verify a purchase before delivering the product.
    // For the purpose of an example, we directly return true.
    // print('_verifyPurchase ${purchaseDetails}');
    // odemeSorgula(true);
    Navigator.of(context).pushReplacementNamed(ManagePlan.routeName);
    return Future<bool>.value(true);
  }

  void _handleInvalidPurchase(PurchaseDetails purchaseDetails) {
    // handle invalid purchase here if  _verifyPurchase` failed.
    print('_handleInvalidPurchase');
  }

  void _listenToPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList) {
    print('_listenToPurchaseUpdated');
  //  print('sadasdasdadasdasdasdasdasdasdsadasdsadasdasdasdsadsadasdasdasdasdasdasdas\nasdsadasdsadasdsadasdaasdsadsadsadasdasd' + prefs.getString('_kPrefKey') + 'asdasdasdsadsadasdasdsadasdasdasdsadsad');

    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
      if (purchaseDetails.status == PurchaseStatus.pending) {
        print("showPendingUI");
        showPendingUI();
      } else {
        if (purchaseDetails.status == PurchaseStatus.error) {
          print("purchaseDetails.error}");
          handleError(purchaseDetails.error);
        } else if (purchaseDetails.status == PurchaseStatus.purchased) {
          print("purchaseDetails.status");
          bool valid = await _verifyPurchase(purchaseDetails);
          if (valid) {
            deliverProduct(purchaseDetails);
          } else {
            _handleInvalidPurchase(purchaseDetails);
            return;
          }
        }
        if (Platform.isAndroid) {
          if (!kAutoConsume && purchaseDetails.productID == _kConsumableId) {
            await InAppPurchaseConnection.instance
                .consumePurchase(purchaseDetails);
          }
        }
        if (purchaseDetails.pendingCompletePurchase) {
          print("purchaseDetails.pendingCompletePurchase");
          await InAppPurchaseConnection.instance
              .completePurchase(purchaseDetails);
        }

      }

    });

  }

}


















/*
import 'package:dietlife/screens/auth_screen.dart';
import 'package:dietlife/services/purchase_service.dart';
import 'package:dietlife/widgets/purchase_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:dietlife/main.dart';
import 'dart:io' show Platform;

class InitialPurchaseScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _InitialPurchaseState();
}

PurchasesService purchasesService = PurchasesService();

class _InitialPurchaseState extends State<InitialPurchaseScreen> {

  PurchaserInfo _purchaserInfo;
  String satinAlmaIslem = '';




  @override
  void initState() {
    initPlatformState();
    listenPurchaseUpdate();

    String os = Platform.operatingSystem;
    if(os == 'ios'){
      satinAlmaIslem = 'diyetlifeaylik';
    }else{
      satinAlmaIslem = 'diyetlife_';
    }

    super.initState();
  }

  listenPurchaseUpdate() async {
    Purchases.addPurchaserInfoUpdateListener((purchaserInfo) => {
          if (purchaserInfo.entitlements.all[satinAlmaIslem].isActive)
            {prefs.setBool("premiumState", true)}
          else
            {prefs.setBool("premiumState", false)}
        });
  }

  Future<void> initPlatformState() async {
    await Purchases.setDebugLogsEnabled(true);
    await Purchases.setup("zOlwlpTNvSlDbbvXCMzJHHznVjGnrEAW");
    PurchaserInfo purchaserInfo = await Purchases.getPurchaserInfo();

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;


    setState(() {
      _purchaserInfo = purchaserInfo;
    });
  }

  // Platform messages are asynchronous, so we initialize in an async method.

  @override
  Widget build(BuildContext context) {



    if (_purchaserInfo == null) {
      return Scaffold(
        appBar: AppBar(title: Text("Diet Life")),
        body: Center(child: CircularProgressIndicator()),
      );
    } else {
      var isPro = prefs.getBool("premiumState");
      if (isPro == true) {
        return AuthScreen();
      } else {
        return UpsellScreen();
      }
    }
  }
}

class UpsellScreen extends StatefulWidget {
  // Bu ekran satın alma ekranı
  @override
  State<StatefulWidget> createState() => _UpsellScreenState();
}

class _UpsellScreenState extends State<UpsellScreen> {
  Offerings _offerings;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    Offerings offerings;
    try {
      offerings = await Purchases.getOfferings();
    } on PlatformException catch (e) {
      print(e);
    }

    if (!mounted) return;

    setState(() {
      _offerings = offerings;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_offerings != null) {

      final offering = _offerings.current;
      if (offering != null) {

       final monthly = offering.monthly;

        if (monthly != null) {
          return Scaffold(
              appBar: AppBar(title: Text("Satın Alma Ekranı")),
              body: Center(
                  child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    "Aylık Üyelik",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 25,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  PurchasedButton(package: monthly),
                  SizedBox(
                    height: 25,
                  ),
                  Text(
                    "Premium içeriği",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 25,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    padding: EdgeInsets.all(5),
                    height: 450,
                    width: 300,
                    child: SingleChildScrollView(
                      child: Text(
                          """✔️ Diyetisyene gitmenize gerek kalmadan çok rahat bir şekilde kilolarınızdan kurtulabileceksiniz.
  ✔️Herhangi bir sıkıntınızda WHATSAPP destek hattımız üzerinden alanında uzman diyetisyenlere ücretsiz bir şekilde danışarak yanıtsız sorunuz kalmayacak.
  ✔️Sizin antropometrik verilerinize göre (kilo, boy, cinsiyet, vb.) size özel oluşturulmuş diyet planı sayesinde kilolarınıza elveda diyeceksiniz.\n\n
KİLO KAYBI GARANTİSİ VERİYOR MU ?
KESİNLİKLE EVET. Şuana kadar programı kullanan yüzlerce insan gibi sizde çok rahat bir şekilde kilo verebileceksiniz
GÜVENLİ Mİ ?
Program tamamen bilimsel verilerin ışığında yapıldığı için % 100 güvenilirdir.
"""),
                    ),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                            width: 3, color: Theme.of(context).primaryColor)),
                  )
                ],
              )));
        }
      }
   }
    return Scaffold(
        appBar: AppBar(title: Text("Satın Alma Ekranı")),
        body: Center(
          child: CircularProgressIndicator(),
        ));
  }
 }



 */