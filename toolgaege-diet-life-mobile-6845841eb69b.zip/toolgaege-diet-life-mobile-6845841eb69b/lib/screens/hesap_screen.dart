import 'package:dietlife/providers/auth.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/auth_screen.dart';
import 'package:flutter/material.dart';
import 'package:toast/toast.dart';
import 'package:provider/provider.dart';
class HesapScreen extends StatefulWidget {
  static const routeName = '/hesap-screen';

  @override
  _HesapScreenState createState() => _HesapScreenState();
}

class _HesapScreenState extends State<HesapScreen> {



  String name = '';
  String surname = '';
  String email='';

  bool isLoading = false;
  var _isInit = true;
  @override
  void didChangeDependencies() async{

    setState(() {
      isLoading = true;
    });

    if(_isInit){
        var userProvider = Provider.of<User>(context,listen: false);
        await userProvider.fetchAndSetUser();
        name = userProvider.name;
        surname = userProvider.surname;
        email = userProvider.email;
      }
    _isInit = false;


    setState(() {
      isLoading = false;
    });
    super.didChangeDependencies();
  }

  _showPasswordChangeDialog(BuildContext context){

    showDialog(
        context: context,
        builder: (_) => new AlertDialog(
          title: new Text("Şifre Değiş"),
          content:  Text('Uygulamadan Çıkış Yapılacak ve Email Adresinize Şifre Yenileme Linki gönderilecek.'),
          actions: <Widget>[
            FlatButton(
              child: Text('Onayla'),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushReplacementNamed(AuthScreen.routeName);
                Provider.of<Auth>(context,listen: false).logout();
                Provider.of<Auth>(context,listen: false).sendEmail(email);
              },
            ),
            FlatButton(
              child: Text('İptal'),
              onPressed: () {

                Navigator.of(context).pop();

              },
            ),
          ],
        ));
  }

  _showPasswordChangeDialog1(BuildContext context){
    TextEditingController mevcutSifre = TextEditingController();
    TextEditingController yeniSifre = TextEditingController();
    TextEditingController onayla = TextEditingController();

    showDialog(
        context: context,
        builder: (_) => new AlertDialog(
          title: new Text("Şifre Değiş"),
          content:  SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: mevcutSifre,
                  decoration: InputDecoration(
                      labelText: 'Mevcut Şifre',
                      border: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10))
                      )
                  ),
                ),
                Divider(color: Theme.of(context).primaryColor,),
                TextField(
                  controller: yeniSifre,
                  decoration: InputDecoration(
                      labelText: 'Yeni Şifre',
                      border: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10))
                      )
                  ),
                ),
                Divider(color: Theme.of(context).primaryColor,),
                TextField(
                  controller: onayla,
                  decoration: InputDecoration(
                      labelText: 'Şifreyi Onayla',
                      border: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10))
                      )
                  ),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('Onayla'),
              onPressed: () {
                if(yeniSifre.text!=onayla.text){
                  Toast.show("Girdiğiniz Şifreler Aynı Olmalıdır", context, duration: Toast.LENGTH_LONG, gravity:  Toast.BOTTOM);

                }
              },
            ),
            FlatButton(
              child: Text('İptal'),
              onPressed: () {

                Navigator.of(context).pop();

              },
            ),
          ],
        ));
  }

  @override
  Widget build(BuildContext context) {
    TextStyle firstStyle = TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 18,
        color: Colors.black
    );

    TextStyle secondStyle = TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 18,
        color: Theme.of(context).primaryColor
    );
    return Scaffold(
      appBar: AppBar(
        title: Text('Hesap Bilgileri'),
      ),
      body: isLoading?
      Center(child: CircularProgressIndicator(),)
      :SingleChildScrollView(
      child: Column(
        children: [
          Container(
            height: 20,
          ),
          Divider(color: Theme.of(context).primaryColor,),
          GestureDetector(
            onTap: (){
             // _showNameChangeDialog();
            },
            child: Container(
              color: Colors.transparent,
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Ad',style: firstStyle,),
                    Text(name,style: secondStyle,)
                  ],
                ),
              ),
            ),
          ),
          Divider(color: Theme.of(context).primaryColor,),
          GestureDetector(
            onTap: (){
              // _showNameChangeDialog();
            },
            child: Container(
              color: Colors.transparent,
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Soyad',style: firstStyle,),
                    Text(surname,style: secondStyle,)
                  ],
                ),
              ),
            ),
          ),
          Divider(color: Theme.of(context).primaryColor,),
          GestureDetector(
            onTap: (){
              // _showNameChangeDialog();
            },
            child: Container(
              color: Colors.transparent,
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Email',style: firstStyle,),
                    Text(email,style: secondStyle,)
                  ],
                ),
              ),
            ),
          ),
          Divider(color: Theme.of(context).primaryColor,),
          GestureDetector(
            onTap: (){
              _showPasswordChangeDialog(context);
            },
            child: Container(
              color: Colors.transparent,
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Şifre değiş',style: firstStyle,),
                    Text('*****',style: secondStyle,),
                  ],
                ),
              ),
            ),
          ),
          Divider(color: Theme.of(context).primaryColor,)
        ],
      ),
      ),
    );
  }
}
