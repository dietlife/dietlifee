import 'package:dietlife/providers/user.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
class GecmisTartiScreen extends StatefulWidget {
  static const routeName = 'gecmis-tarti-screen';

  @override
  _GecmisTartiScreenState createState() => _GecmisTartiScreenState();
}

class _GecmisTartiScreenState extends State<GecmisTartiScreen> {

  bool isLoading = false;
  var _isInit = true;

  Future<void> _refreshIndicator(BuildContext context) async {
    await Provider.of<User>(context,listen: false).fetchAndSetTarti();
  }

  @override
  void didChangeDependencies() async{

    setState(() {
      isLoading = true;
    });

    if(_isInit){
        //await Provider.of<User>(context,listen: false).fetchAndSetTarti();

    }
    _isInit = false;


    setState(() {
      isLoading = false;
    });
    super.didChangeDependencies();
  }

  String getDate(String date){
    var dDate = DateTime.parse(date);

    return '${dDate.day}/${dDate.month}/${dDate.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Geçmiş Tartı Bilgileri'),
      ),
      body: FutureBuilder(
        future: _refreshIndicator(context),
        builder: (ctx,snapShot) =>
        snapShot.connectionState == ConnectionState.waiting
            ?Center(
          child: CircularProgressIndicator(),
        ):
        RefreshIndicator(
          onRefresh: () {
            _refreshIndicator(context);
          },
          child: Consumer<User>(
            builder: (ctx,usersData,_)
            =>Padding(
              padding: EdgeInsets.all(8),
              child: ListView.builder(
                itemCount: usersData.tartiInfiList.length,
                itemBuilder: (ctx,i) => Column(
                  children: [
                    Card(
                      child: ListTile(
                        title: Text('Kilo: ${usersData.tartiInfiList[i].split('&')[1]}'),
                        subtitle: Text(getDate(usersData.tartiInfiList[i].split('&')[0])),
                      ),
                    ),
                    Divider()
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
