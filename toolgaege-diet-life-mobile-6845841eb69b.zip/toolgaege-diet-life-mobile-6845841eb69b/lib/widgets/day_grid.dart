import 'package:dietlife/providers/days.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'day_item.dart';
class DayGrid extends StatelessWidget {

  final int calori;

  DayGrid(this.calori);

  @override
  Widget build(BuildContext context) {
    final dayData = Provider.of<Days>(context);
    final days = dayData.items;

    return GridView.builder(
      padding: const EdgeInsets.all(10.0),
      itemCount: days.length,
      itemBuilder: (ctx , i) => ChangeNotifierProvider.value(
        value:days[i],
        child: DayItem(
          calori
//        id: products[i].id,
//        title: products[i].title,
//        imageUrl: products[i].imageUrl,
        ),
      ),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount:  4,
          childAspectRatio: 3/3,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10
      ),
    );
  }
}
