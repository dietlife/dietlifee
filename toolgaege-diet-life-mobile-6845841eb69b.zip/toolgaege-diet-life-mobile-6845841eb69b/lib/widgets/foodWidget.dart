import 'package:flutter/material.dart';

class FoodWidget extends StatefulWidget {

  final String food;



  FoodWidget({Key key,@required this.food}):super(key:key);

  @override
  FoodWidgetState createState() => FoodWidgetState();
}

class FoodWidgetState extends State<FoodWidget> {

  String food;
  List<PopupMenuItem<String>> popUpMenuItems;
  int selectedFood =0;
  String ogun;
  bool hasAlt = false;

  String getfood(){
    print('food ogun: $ogun');
    return ogun;
  }

  @override
  void initState() {

    food = widget.food;
    if(food.contains("&alt&",0)){
      hasAlt = true;
      if(food.split("&alt&").length>1){
        List<String> items = [];
        for(int i=0;i<food.split("&alt&").length;i++){
          items.add(food.split("&alt&")[i]);
        }
        popUpMenuItems = items
            .map(
              (String value) => PopupMenuItem<String>(
            value: value,
            child: Text(value),
          ),
        )
            .toList();
      }
    }else{
      hasAlt = false;
    }

    ogun = food.split("&alt&")[selectedFood];

    super.initState();
  }

  ListTile getListTile(){
    if(hasAlt){
      return ListTile(
        leading: Icon(Icons.fiber_manual_record),
        title:  Text(
          ogun,
          style: TextStyle(fontSize: 18.0,color:Colors.black,fontFamily: "Kalam"),
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            new PopupMenuButton<String>(
              onSelected: (String newValue) {
                setState(() {
                  ogun = newValue;
                });
              },
              itemBuilder: (BuildContext context) => popUpMenuItems,
            ),
          ],
        )
      );
    }else{
     return ListTile(
        leading: Icon(Icons.fiber_manual_record),
        title:  Text(
          ogun,
          style: TextStyle(fontSize: 18.0,color:Colors.black,fontFamily: "Kalam"),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return getListTile();
  }
}
