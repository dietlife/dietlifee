import 'package:dietlife/DB/DBHelper.dart';
import 'package:dietlife/providers/days.dart';
import 'package:dietlife/providers/globals.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/widgets/titleWidget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'foodKahvaltiWidget.dart';
import 'foodWidget.dart';

class DietPage extends StatefulWidget {

  final String dietProgram;

  DietPage({Key key,this.dietProgram}) : super(key: key);

  @override
  DietPageState createState() => DietPageState();
}

class DietPageState extends State<DietPage> {


  final dbHelper = DatabaseHelper.instance;
  int calori;
  String dietProgram;
  int selectedKahvalti = 0;
  int kahvaltiItemCount = 0;
  List<Widget> dietList = [];
  List<List<Widget>> kahvaltilar = [];
  String totalDay;
  List<List<GlobalKey<FoodKahvaltiWidgetState>>> keyKahvalti = [];

  List<GlobalKey<FoodWidgetState>> keySingleKahvaltiList =  [];
  List<GlobalKey<FoodWidgetState>> keyBirAra = [];
  List<GlobalKey<FoodWidgetState>> keyOgle = [];
  List<GlobalKey<FoodWidgetState>> keyIkiAra =  [];
  List<GlobalKey<FoodWidgetState>> keyAksam =  [];
  List<GlobalKey<FoodWidgetState>> keyUcAra =  [];

  var _isInit = true;
  @override
  void didChangeDependencies() async{



    if(_isInit){
      dietProgram = widget.dietProgram;

    }
    _isInit = false;

    super.didChangeDependencies();
  }


  @override
  void initState() {

    super.initState();
  }

  Widget addDivider(){
    return Padding(
      padding: EdgeInsets.only(top: 20,bottom: 20),
      child: Divider(
        color: Colors.green,
        height: 8,
      ),
    );
  }
  
  setKahvalti(int selectedKahvalti){
    print(selectedKahvalti);
    setState(() {
      this.selectedKahvalti = selectedKahvalti;
    });
  }

  checkKahvalti(String kahvalti, List<Widget> dietList){
    if(kahvalti.contains("&kalt&")){
      dietList.add(TitleWidget(title: "Kahvaltı",popUpMenuItemsCount: kahvalti.split("&kalt&").length,setKahvalti: setKahvalti,));
      getKahvalti(kahvalti, dietList);
    }else{
      dietList.add(TitleWidget(title: "Kahvaltı",popUpMenuItemsCount: 0));
      getKahvalti(kahvalti, dietList);
    }


  }



  getKahvalti(String kahvalti, List<Widget> dietList){
    if(kahvalti.contains("&kalt&")){
      for(int j=0;j<kahvalti.split("&kalt&").length;j++){
        List<Widget> tempList =  [];

        List<GlobalKey<FoodKahvaltiWidgetState>> keyKahvaltiList =  [];
        for(int i = 1;i<kahvalti.split("&kalt&")[j].split("-").length;i++){
          final GlobalKey<FoodKahvaltiWidgetState> _key = GlobalKey();
          keyKahvaltiList.add(_key);
          tempList.add(FoodKahvaltiWidget(key:_key,kahvalti:kahvalti ,foodIndex: i,selectedKahvalti: j));
        }
        keyKahvalti.add(keyKahvaltiList);
        kahvaltilar.add(tempList);
      }

      dietList.addAll(kahvaltilar[selectedKahvalti]);
    }else{
      for(int i = 1;i<kahvalti.split("-").length;i++){
        final GlobalKey<FoodWidgetState> _key = GlobalKey();
        dietList.add(FoodWidget(key:_key, food:kahvalti.split("-")[i]));
        keySingleKahvaltiList.add(_key);
      }
    }
  }

  getBirAra(String birAra,List<Widget> dietList){
    dietList.add(TitleWidget(title: "1. Ara",popUpMenuItemsCount: 0));
    for(int i = 1;i<birAra.split("-").length;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:birAra.split("-")[i]));
      keyBirAra.add(_key);
    }
  }
  getOgle(String ogle,List<Widget> dietList){
    dietList.add(TitleWidget(title: "Öğle",popUpMenuItemsCount: 0));
    for(int i = 1;i<ogle.split("-").length;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:ogle.split("-")[i]));
      keyOgle.add(_key);
    }
  }
  getIkiAra(String ikiAra,List<Widget> dietList){
    dietList.add(TitleWidget(title: "2. Ara",popUpMenuItemsCount: 0));
    for(int i = 1;i<ikiAra.split("-").length;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:ikiAra.split("-")[i]));
      keyIkiAra.add(_key);
    }
  }
  getAksam(String aksam,List<Widget> dietList){
    dietList.add(TitleWidget(title: "Akşam",popUpMenuItemsCount: 0));
    for(int i = 1;i<aksam.split("-").length;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:aksam.split("-")[i]));
      keyAksam.add(_key);
    }
  }
  getUcAra(String ucAra,List<Widget> dietList){
    dietList.add(TitleWidget(title: "3. Ara",popUpMenuItemsCount: 0));
    for(int i = 1;i<ucAra.split("-").length;i++){
      final GlobalKey<FoodWidgetState> _key = GlobalKey();
      dietList.add(FoodWidget(key:_key,food:ucAra.split("-")[i]));
      keyUcAra.add(_key);
    }
  }



  List<Widget> getList(String content){
    dietList.clear();
    calori = int.parse(content.split("&ogun&")[0]);
    checkKahvalti(content.split("&ogun&")[1],dietList);
    dietList.add(addDivider());
    getBirAra(content.split("&ogun&")[2],dietList);
    dietList.add(addDivider());
    getOgle(content.split("&ogun&")[3],dietList);
    dietList.add(addDivider());
    getIkiAra(content.split("&ogun&")[4],dietList);
    dietList.add(addDivider());
    getAksam(content.split("&ogun&")[5],dietList);
    dietList.add(addDivider());
    getUcAra(content.split("&ogun&")[6],dietList);
    return dietList;
  }


  addItem(String item){
    totalDay = "$totalDay$item";
  }

  buildDay(DateTime currentDietDate,String userId){

    print('bilgiler listelenecek');
    print(currentDietDate);
    print(keyBirAra);

    totalDay = "";
    if(keySingleKahvaltiList.isEmpty){
      for(int i =0; i<keyKahvalti[selectedKahvalti].length;i++){
        addItem(keyKahvalti[selectedKahvalti][i].currentState.getfood());
        addItem("-");

      }
    }else {
      for(int i =0;i<keySingleKahvaltiList.length;i++){
        addItem(keySingleKahvaltiList[i].currentState.getfood());
        addItem("-");
      }
    }

    addItem("||");
    print('kahvalti gecildi');

    if(keyBirAra.isNotEmpty){
      print('1');
      for(int i =0;i<keyBirAra.length;i++){
        print('2');
        addItem(keyBirAra[i].currentState.getfood());
        print('3');
        addItem("-");
      }
    }

    addItem("||");
    print('kahvalti gecildi');
    if(keyOgle.isNotEmpty){
      for(int i =0;i<keyOgle.length;i++){
        addItem(keyOgle[i].currentState.getfood());
        addItem("-");
      }
    }

    addItem("||");
    print('kahvalti gecildi');
    if(keyIkiAra.isNotEmpty){
      for(int i =0;i<keyIkiAra.length;i++){
        addItem(keyIkiAra[i].currentState.getfood());
        addItem("-");
      }
    }

    addItem("||");
    print('kahvalti gecildi');
    if(keyAksam.isNotEmpty){
      for(int i =0;i<keyAksam.length;i++){
        addItem(keyAksam[i].currentState.getfood());
        addItem("-");
      }
    }

    addItem("||");
    print('kahvalti gecildi');
    if(keyUcAra.isNotEmpty){
      for(int i =0;i<keyUcAra.length;i++){
        addItem(keyUcAra[i].currentState.getfood());
        addItem("-");
      }
    }

    _insert(currentDietDate.toString(),userId);

  }

  void _insert(String date,String userId) async {
    var userProvider = Provider.of<User>(context,listen: false);
    await userProvider.fetchAndSetUser();
    var userId = userProvider.userId;
    var columnId = '${DateTime.parse(date).day}/${DateTime.parse(date).month}/${DateTime.parse(date).year}';
    final allRows = await dbHelper.queryRows('$columnId&$userId');
    int id = 0;
    if(allRows.length==0){
      Map<String, dynamic> row = {
        DatabaseHelper.columnId : '$columnId&$userId',
        DatabaseHelper.columnPlan : totalDay,
        DatabaseHelper.columnCalori  : calori
      };
       id = await dbHelper.insert(row);
      Provider.of<Days>(context,listen:false).updateDayFromPlans(date, id, calori);
    }else{
      _update(date,id);
    }

    // row to insert

  }

  void _update(String date,int id) async {
    // row to update
    var userProvider = Provider.of<User>(context,listen: false);
    await userProvider.fetchAndSetUser();
    var userId = userProvider.userId;
    var columnId = '${DateTime.parse(date).day}/${DateTime.parse(date).month}/${DateTime.parse(date).year}';

    Map<String, dynamic> row = {
      DatabaseHelper.columnId   : '$columnId&$userId',
      DatabaseHelper.columnPlan : totalDay,
      DatabaseHelper.columnCalori  : calori
    };
    await dbHelper.update(row);
    Provider.of<Days>(context,listen:false).updateDayFromPlans(date, id, calori);
  }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: getList(dietProgram),
        ),
      ),
    );
  }
}
