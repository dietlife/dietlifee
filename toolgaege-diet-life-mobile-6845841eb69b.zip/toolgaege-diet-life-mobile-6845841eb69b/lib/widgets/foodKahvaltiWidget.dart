import 'package:flutter/material.dart';

class FoodKahvaltiWidget extends StatefulWidget {

  final String kahvalti;
  final int selectedKahvalti;
  final int foodIndex;



  FoodKahvaltiWidget({Key key,@required this.kahvalti,@required this.selectedKahvalti,@required this.foodIndex}):super(key:key);
  @override
  FoodKahvaltiWidgetState createState() => FoodKahvaltiWidgetState();
}

class FoodKahvaltiWidgetState extends State<FoodKahvaltiWidget> {

  String kahvalti;
  String food;
  List<PopupMenuItem<String>> popUpMenuItems;
  int selectedFood =0;
  String ogun;
  int selectedKahvalti;
  int foodIndex;
  bool hasAlt=false;

  String getfood(){
    print('ogun: $ogun');
    return ogun;
  }

  setFood(){
    kahvalti = widget.kahvalti;
    foodIndex=widget.foodIndex;
    selectedKahvalti=widget.selectedKahvalti;
    food = kahvalti.split("&kalt&")[selectedKahvalti].split("-")[foodIndex];
    if(food.contains("&alt&",0)){
      hasAlt = true;
      if(food.split("&alt&").length>1){
        List<String> items = [];
        for(int i=0;i<food.split("&alt&").length;i++){
          items.add(food.split("&alt&")[i]);
        }
        popUpMenuItems = items
            .map(
              (String value) => PopupMenuItem<String>(
            value: value,
            child: Text(value),
          ),
        )
            .toList();
      }
    }else{
      hasAlt = false;
    }


    setState(() {
      ogun = food.split("&alt&")[selectedFood];
    });

  }

  @override
  void initState() {

    setFood();
    super.initState();
  }

  ListTile getListTile(){
    if(hasAlt){
      return ListTile(
        leading: Icon(Icons.fiber_manual_record),
        title:  Text(
          ogun,
          style: TextStyle(fontSize: 18.0,color:Colors.black,fontFamily: "Kalam"),
        ),
        trailing: Container(
          height: double.infinity,
          child: new PopupMenuButton<String>(
            onSelected: (String newValue) {
              setState(() {
                ogun = newValue;
              });
            },
            itemBuilder: (BuildContext context) => popUpMenuItems,
          ),
        )
      );
    }else{
      return ListTile(
        leading: Icon(Icons.fiber_manual_record),
        title:  Text(
          ogun,
          style: TextStyle(fontSize: 18.0,color:Colors.black,fontFamily: "Kalam"),
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return getListTile();
  }
}
