import 'package:dietlife/providers/auth.dart';
import 'package:dietlife/screens/auth_screen.dart';
import 'package:dietlife/screens/cooker_screen.dart';
import 'package:dietlife/screens/dailyPlan.dart';
import 'package:dietlife/screens/managePlan.dart';
import 'package:dietlife/screens/profile_page.dart';
import 'package:dietlife/screens/purchase_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: <Widget>[
          AppBar(
            title: Text('Diet Life'),
            automaticallyImplyLeading: false,
          ),
          Divider(),
          ListTile(
            leading: Icon(
                Icons.shop
            ),
            title: Text('Günlük Plan'),
            onTap: (){
              Navigator.of(context).pushReplacementNamed(DailyPlan.routeName);
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(
                Icons.payment
            ),
            title: Text('Planları Yönet'),
            onTap: (){
              Navigator.of(context).pushReplacementNamed(purchaseScreenNew.routeName);
            },

          ),
          Divider(),
          ListTile(
            leading: Icon(
                Icons.set_meal
            ),
            title: Text('Basit yemek tarifleri'),
            onTap: (){
              Navigator.of(context).pushReplacementNamed(RecipeScreen.routeName);
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(
                Icons.edit
            ),
            title: Text('Profil Sayfası'),
            onTap: (){
              Navigator.of(context).pushReplacementNamed(ProfilePage.routeName);
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(
                Icons.exit_to_app
            ),
            title: Text('Çıkış'),
            onTap: (){
              Provider.of<Auth>(context,listen: false).logout();
              Navigator.pushReplacementNamed(context, AuthScreen.routeName);
            },
          )
        ],
      ),
    );
  }
}
