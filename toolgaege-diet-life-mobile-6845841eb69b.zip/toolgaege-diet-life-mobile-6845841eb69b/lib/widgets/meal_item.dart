import 'package:dietlife/providers/meal.dart';
import 'package:dietlife/screens/meal_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MealItem extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final meal = Provider.of<Meal>(context,listen: false);

    return ClipRRect(
      borderRadius: BorderRadius.circular(10.0),
      child: GridTile(

        child: GestureDetector(
          onTap: (){
            Navigator.of(context).pushNamed(MealDetailScreen.routeName, arguments: meal.id);
          },
          child: Image.network(
            meal.link,
            fit: BoxFit.cover,
          ),
        ),
        footer: GridTileBar(
          backgroundColor: Colors.black87,
          title: Text(
            meal.title,
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
