import 'package:flutter/material.dart';

class TitleWidget extends StatefulWidget {
  final String title;
  final int popUpMenuItemsCount;
  final Function setKahvalti;

  TitleWidget({@required this.title,this.popUpMenuItemsCount,this.setKahvalti});




  @override
  _TitleWidgetState createState() => _TitleWidgetState();
}

class _TitleWidgetState extends State<TitleWidget> {

  String title;
  List<PopupMenuItem<String>> popUpMenuItems;
  Function setKahvalti;


  Widget getAssets(){
    Image image;
    var dimen = 50.0;
    switch(title){
      case 'Kahvaltı':{
       image = Image.asset('assets/ogunler/kahvalti.png',height: dimen,width: dimen,);
      }break;
      case '1. Ara':{
        image = Image.asset('assets/ogunler/1ara.png',height: dimen,width: dimen,);
      }break;
      case 'Öğle':{
        image = Image.asset('assets/ogunler/ogle.jpg',height: dimen,width: dimen,);
      }break;
      case '2. Ara':{
        image = Image.asset('assets/ogunler/2ara.png',height: dimen,width: dimen,);
      }break;
      case 'Akşam':{
        image = Image.asset('assets/ogunler/aksam.png',height: dimen,width: dimen,);
      }break;
      case '3. Ara':{
        image = Image.asset('assets/ogunler/3ara.png',height: dimen,width: dimen,);
      }break;
    }

    return image;
  }

  Widget getTitle(){
    if(widget.popUpMenuItemsCount == 0||true){
      return ListTile(
        leading: getAssets(),
        title:  Text(
          title,
          style: TextStyle(fontSize: 18.0,color:Colors.red,fontWeight: FontWeight.bold,fontFamily: "Kalam"),
        ),
      );
    }else{
      return ListTile(
        leading: getAssets(),
        title:  Text(
          title,
          style: TextStyle(fontSize: 18.0,color:Colors.red,fontWeight: FontWeight.bold,fontFamily: "Kalam"),
        ),
        trailing: new PopupMenuButton<String>(
          onSelected: (String newValue) {
            setKahvalti((int.parse(newValue.split(".")[0]))-1);
          },
          itemBuilder: (BuildContext context) => popUpMenuItems,
        ),
      );
    }
  }

  @override
  void initState() {
    if(widget.popUpMenuItemsCount != null){
      List<String> items = [];
      for(int i=0;i<widget.popUpMenuItemsCount;i++){
        items.add("${i+1}. Seçenek");
      }
      popUpMenuItems = items
          .map(
            (String value) => PopupMenuItem<String>(
          value: value,
          child: Text(value),
        ),
      )
          .toList();
    }

    title = widget.title;
    setKahvalti = widget.setKahvalti;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return getTitle();
  }
}
