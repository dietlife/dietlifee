import 'package:dietlife/providers/day.dart';
import 'package:dietlife/screens/day_detail_screen.dart';
import 'package:dietlife/screens/meal_detail_screen.dart';
import 'package:dietlife/screens/plans_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
// import 'package:intl/intl.dart';

class DayItem extends StatelessWidget {


  final int calori;
  DayItem(this.calori);

  List<String> aylar = [
    "Ocak",
    "Şubat",
    "Mart",
    "Nisan",
    "Mayıs",
    "Haziran",
    "Temmuz",
    "Ağustos",
    "Eylül",
    "Ekim",
    "Kasım",
    "Aralık",
  ];




  @override
  Widget build(BuildContext context) {
    final day = Provider.of<Day>(context,listen: false);


    return ClipRRect(
      borderRadius: BorderRadius.circular(15.0),

      child: GridTile(
        child: GestureDetector(
            onTap: (){

              if(day.id != ''){
                Navigator.of(context).pushNamed(DayDetailScreen.routeName, arguments: [day.date,calori]);
              }else{
                Navigator.of(context).pushNamed(PlansScreen.routeName, arguments: [day.date,calori]);
              }
            },
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(),
                color: day.id==''? Colors.red:Theme.of(context).primaryColor
              ),
              padding: EdgeInsets.only(top: 15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(
                    '${DateTime.parse(day.date).day} \n${aylar[DateTime.parse(day.date).month-1]}',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Colors.white
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            )
        ),
      ),
    );





  }
}
