import 'package:dietlife/providers/auth.dart';
import 'package:dietlife/providers/current_user.dart';
import 'package:dietlife/providers/days.dart';
import 'package:dietlife/providers/meals.dart';
import 'package:dietlife/providers/user.dart';
import 'package:dietlife/screens/auth_screen.dart';
import 'package:dietlife/screens/content/view/content_view.dart';
import 'package:dietlife/screens/cooker_screen.dart';
import 'package:dietlife/screens/dailyPlan.dart';
import 'package:dietlife/screens/day_detail_screen.dart';
import 'package:dietlife/screens/feedback_screen.dart';
import 'package:dietlife/screens/fiziksel_activite_screen.dart';
import 'package:dietlife/screens/gecmis_tarti_screen.dart';
import 'package:dietlife/screens/gizlilik_politikasi_screen.dart';
import 'package:dietlife/screens/hakkimda_screen.dart';
import 'package:dietlife/screens/hesap_screen.dart';
import 'package:dietlife/screens/home_screen.dart';
import 'package:dietlife/screens/iletisim_screen.dart';
import 'package:dietlife/screens/istek_screeen.dart';
import 'package:dietlife/screens/managePlan.dart';
import 'package:dietlife/screens/meal_detail_screen.dart';
import 'package:dietlife/screens/personel_info_page.dart';
import 'package:dietlife/screens/plans_screen.dart';
import 'package:dietlife/screens/profile_page.dart';
import 'package:dietlife/screens/purchase_screen.dart';
import 'package:dietlife/screens/signup_screen.dart';
import 'package:dietlife/screens/splash_screen.dart';
import 'package:dietlife/screens/sport_info_screen.dart';
import 'package:dietlife/screens/yasal_uyari_screen.dart';
import 'package:dietlife/screens/zorluk_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
SharedPreferences prefs;
void main() async{
  SharedPreferences.setMockInitialValues({});
  WidgetsFlutterBinding.ensureInitialized();
  InAppPurchaseConnection.enablePendingPurchases();
  prefs = await SharedPreferences.getInstance();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (ctx) => Auth(),
          ),
          ChangeNotifierProxyProvider<Auth,Meals>(
            update: (ctx,auth,_) => Meals(
              auth.token,
            ),
          ),
          ChangeNotifierProvider(
            create: (ctx) => Days(),
          ),
          ChangeNotifierProxyProvider<Auth,User>(
            update: (ctx,auth,_) => User(
              auth.token,
              auth.userId,
            ),
          ),
        ],
        child: Consumer<Auth>(
          builder: (ctx,auth,_) => MaterialApp(
            title: 'DietLife',
            theme: ThemeData(
                primarySwatch: Colors.green,
                accentColor: Colors.lightGreen,
                fontFamily: 'Lato'

            ),
            home: auth.isAuth ? HomePage()
                : FutureBuilder(
                future: auth.tryAutoLogin(),
                builder: (ctx,autoResultSnapshot) =>
                autoResultSnapshot.connectionState == ConnectionState.waiting ?
                SplashScreen() :AuthScreen()),
            routes: {
              DailyPlan.routeName:(ctx) => DailyPlan(),
              ManagePlan.routeName:(ctx) => ManagePlan(),
              ProfilePage.routeName:(ctx) => ProfilePage(),
              RecipeScreen.routeName:(ctx) => RecipeScreen(),
              PersonelInfoPage.routeName:(ctx) => PersonelInfoPage(),
              SportInfoScreen.routeName:(ctx)=>SportInfoScreen(),
              MealDetailScreen.routeName:(ctx) => MealDetailScreen(),
              DayDetailScreen.routeName:(ctx) => DayDetailScreen(),
              PlansScreen.routeName:(ctx) => PlansScreen(),
              HesapScreen.routeName:(ctx) => HesapScreen(),
              HakkimdaScreen.routeName:(ctx) => HakkimdaScreen(),
              FeedBackScreen.routeName:(ctx) => FeedBackScreen(),
              YasalUyariScreen.routeName:(ctx) => YasalUyariScreen(),
              GizlilikPolitikasiScreen.routeName:(ctx) => GizlilikPolitikasiScreen(),
              IletisimScreen.routeName:(ctx) => IletisimScreen(),
              SignupScreen.routeName:(ctx) => SignupScreen(),
              FizikselAktiviteScreen.routeName:(ctx) => FizikselAktiviteScreen(),
              IstekScreen.routeName:(ctx) => IstekScreen(),
              ZorlukScreen.routeName:(ctx) => ZorlukScreen(),
              AuthScreen.routeName:(ctx) => AuthScreen(),
              GecmisTartiScreen.routeName:(ctx) => GecmisTartiScreen(),
              HomePage.routeName:(ctx) => HomePage(),
              purchaseScreenNew.routeName:(ctx) => purchaseScreenNew(),
              ContentView.routeName:(ctx) => ContentView(),
            },
          ),
        ));
  }
}


